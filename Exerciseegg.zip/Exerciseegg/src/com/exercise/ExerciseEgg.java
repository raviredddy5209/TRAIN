package com.exercise;

import java.util.Scanner;

public class ExerciseEgg {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		 Scanner sc = new Scanner(System.in);
	        System.out.println("Enter no of Eggs");
	        int noofeggs=sc.nextInt();
	       int gross  = noofeggs/144;
	       int grossrem = noofeggs%144;
	       int dozen = grossrem/12;
	       int dozenrem = grossrem%12;
	      
	         System.out.println("No of gross "  + gross + "\n" +"no of dozens" +dozen+ "\n" + "remaining"  + dozenrem);
	}

}
