package com.exercise;
import java.util.p
import java.util.Scanner;
public class Reverse {
	public static void main(String args[])
	{
		String temp;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the string");
		String word=scanner.nextLine();
		String splitarr[]=word.split(" ");
		String revwords=" ";
		for(int i=0;i<splitarr.length;i++)
		{
			revwords=" ";
			for(int j=splitarr[i].length()-1;j>=0;j--)
			{
				revwords=revwords+splitarr[i].charAt(j);
			}
			splitarr[i]=revwords;
		}
		for(int i=0;i<splitarr.length;i++)
		{
			for(int j=i+1;j<splitarr.length;j++)
			{
				if(splitarr[i].compareTo(splitarr[j])>0)
				{
					temp=splitarr[i];
					splitarr[i]=splitarr[j];
					splitarr[j]=temp;
				}	
			}
			System.out.print(splitarr[i]+" "); 
		}
	}
}