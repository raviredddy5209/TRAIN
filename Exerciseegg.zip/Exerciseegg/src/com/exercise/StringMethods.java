package com.exercise;

public class StringMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="The quick brown fox jumps over the lazy dog";
		System.out.println("1. The Character at 12th index is"+str.charAt(12));
		System.out.println("2. Whether string contains is"+str.contains("is"));
		String s2=str+"and killed it";
		System.out.println("4. "+s2);
		System.out.println("5. Whether string ends with dogs"+str.endsWith("dogs"));
		System.out.println(str.equals("The quick brown Fox jumps over the lazy Dog"));
		System.out.println(str.equals("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG"));
		System.out.println(str.indexOf("a"));
		System.out.println(str.lastIndexOf("e"));
		System.out.println(str.length());
		System.out.println(str.matches("The quick brown Fox jumps over the lazy Dog"));
		String s3=str.replace("The","A");
		System.out.println(s3);
	    System.out.println(str.toUpperCase());
	    System.out.println(str.toLowerCase());
	    String[] st=str.split(" ");
	    String st1=" ";
	    String st2=" ";
	    boolean b=true;
	    for(int i=0;i<st.length;i++)
	    {
	    	if(b)
	    	{
	    		if(st[i].equals("fox"))
	    		{
	    			b=false;
	    		}
	    		st1+=st[i]+" ";
	    		continue;
	    	}
	    	st2+=st[i]+" ";
	    }
	    System.out.println(st1);
	    System.out.println(st2);
	    	if(str.contains("fox"))
	    	{
	    		System.out.println("fox");
	    	}
	    	if(str.contains("dog"))
	    	{
	    		System.out.println("dog");
	    	}
	    
	}
}