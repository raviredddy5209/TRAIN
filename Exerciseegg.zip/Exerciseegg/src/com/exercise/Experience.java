package com.exercise;
//package com.virtusa.banking.utilities.MavenBankingApplication;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.*;
import java.time.format.DateTimeFormatter;
public class Experience {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String doj;
		Date joiningDate=null;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the date of joining");
		doj=scanner.nextLine();
		SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
        try
        {
        	joiningDate=formatter.parse(doj);
        	System.out.println(new Date().getYear()-joiningDate.getYear());        	
        }
        catch(ParseException e)
        {
        	e.printStackTrace();
        } 
	}
}
