package com.exercise;
import java.util.Scanner;
public class SwitchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		int a;
		int productNo;
		int check=1;
		int quantitySold;
		double price=0;
		System.out.println("Enter the product");
		   productNo=scanner.nextInt();
	       scanner.nextLine();
	       System.out.println("Enter the Quantity Sold");
	       quantitySold=scanner.nextInt();
		while(check==1)
		{ 
			System.out.println("Want to continue or not?");
			a=scanner.nextInt();
			scanner.nextLine();
			  if(productNo==1)
		    	  price=price+(quantitySold*22.50);
		       else if(productNo==2)
		    	   price=price+(quantitySold*44.50);
		       else 
		    	   price=price+(quantitySold*9.98);
			switch(a)
			{
				case 1:System.out.println("Enter the product");
					   productNo=scanner.nextInt();
				       scanner.nextLine();
				       System.out.println("Enter the Quantity Sold");
				       quantitySold=scanner.nextInt();
				       break;
				case 2: a=2;
							break;
			}
			if(a==2)
			{
				check=0;	
			}
		}
		System.out.println("total retail value of all the products sold are:"+price);
	}

}