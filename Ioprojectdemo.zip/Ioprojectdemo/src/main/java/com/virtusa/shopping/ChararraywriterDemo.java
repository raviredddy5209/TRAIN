package com.virtusa.shopping;

import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

public class ChararraywriterDemo {

	public static void main(String[] args)  throws IOException{
		// TODO Auto-generated method stub
		//create directory
File file = new File("com/virtusa/shopping/resources");
if(file.isDirectory())
	System.out.println("Directory Existing");
else
{
	file.mkdirs();
	System.out.println("Directory Created");
}
 
  //file creation
boolean status =false;
File txtFile = new File(file,"file_"+ LocalDate.now().toString()); 
				if(txtFile.exists())
					System.out.println("file exists");
				else
					status = txtFile.createNewFile();
				
				if(status)
					System.out.println("File created");
				else
					System.out.println("file not created");
				//write data in file
				CharArrayWriter writer = new CharArrayWriter( );
				String data = "Virtusa Corporation";
				for(char ch : data.toCharArray())
					writer.write(ch);
				FileWriter fileWriter = new FileWriter(txtFile);
				writer.writeTo(fileWriter);
				System.out.println("Contents Written");
				fileWriter.close();
	
	
	
	}

}
