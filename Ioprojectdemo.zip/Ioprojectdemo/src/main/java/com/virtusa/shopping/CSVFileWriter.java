package com.virtusa.shopping;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;

public class CSVFileWriter {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		boolean status =false;
		File csvfile = new File("com/virtusa/shopping/resources","customer_"+ LocalDate.now().toString()+ ".csv"); 
		if(csvfile.exists())
			System.out.println("file exists");
		else {
			
		if(csvfile.createNewFile()) 
			System.out.println("file created..");

	}
		//Buffered writer
		BufferedWriter writer  = new BufferedWriter(new FileWriter(csvfile));
		Scanner scanner = new Scanner(System.in);
		writer.write("Customer Id,Name,DOB,");
		for(int i=0;i<2;i++)
		{
			System.out.println("Enter Customer Id");
			writer.write(scanner.nextInt() + ",");
			scanner.nextLine();
			System.out.println("Enter Customer Name");
			writer.write(scanner.nextLine() + ",");
			System.out.println("Enter Customer DOB(dd-MM-yyyy)");
			writer.write(scanner.nextLine() +"\n");
		}
		writer.close();

}
}