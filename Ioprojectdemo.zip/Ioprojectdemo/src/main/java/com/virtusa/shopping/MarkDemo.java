package com.virtusa.shopping;

import java.io.StringReader;

public class MarkDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String exp = "1<<<2<3<4<";
		 int i=0;
		 StringReader sr = new  StringReader(exp);
		 try {
			 while((i=sr.read())!=';')
			 {
				 if(i=='<')
				 {
					 sr.mark(1);
					 i=sr.read();
					 if(i=='<')
					 {
						 sr.mark(1);
						 i=sr.read();
						 if(i=='<')
							 System.out.println("Arithmetic Shift");
						 else
							 System.out.println("Logical Shift");
							 
						 
					 }else {
					 System.out.println("Less than");
					 sr.reset();
					 }
				 }else
					 System.out.println((char)i);
				// sr.reset();
			 }
		 
		 }
	}