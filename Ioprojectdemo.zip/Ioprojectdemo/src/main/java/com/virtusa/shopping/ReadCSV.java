package com.virtusa.shopping;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.time.LocalDate;
import java.util.StringTokenizer;
 public class ReadCSV {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File csvfile = new File("com/virtusa/shopping/resources", "customer_"+ LocalDate.now().toString()+ ".csv"); 
					if(csvfile.exists()) 
						System.out.println("file exists"); 
						else {  
						if(csvfile.createNewFile())  
							System.out.println("file created.."); 
				}  
				LineNumberReader reader = new  LineNumberReader(new FileReader(csvfile));
				String str = null;
				StringTokenizer token = null;
				while((str=reader.readLine())!=null)
				{
					token = new StringTokenizer(str, ",");
					while(token.hasMoreTokens())
					{
						System.out.println(reader.getLineNumber()+".");
						System.out.print(token.nextElement()+"\t");
						System.out.print(token.nextElement()+"\t");
						System.out.println(token.nextElement()+"\t");
						
					}
				}
				reader.close();
		
	}
	

}
