package com.virtusa.shopping;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//import com.virtusa.shopping.models.User;
 import com.virtusa.shopping.models.User;

public class ObjrctStreamStream {

	public static void main(String[] args)  throws IOException{
		// TODO Auto-generated method stub
		File file =new File("com/virtusa/shopping/resources","users.dat");
		FileOutputStream fout = null;
		ObjectOutputStream obj = null;
		List<User> users = new ArrayList<User>();
		User user =null;
		for(int i=0;i<100;i++)
		{
			user = new User();
			user.setMobileNo(new Random().nextInt(1000000));
			user.setName("user-" + new Random().nextInt(999));
			user.setDob(LocalDate.now().minusYears(20-i));
			user.setAadharCardNo(new  Random().nextInt(1000000));
			users.add(user);
			
		}
		try
		{
			fout = new FileOutputStream(file);
			obj = new ObjectOutputStream(fout);
			for(User userobj : users)
				obj.writeObject(userobj);
		}catch (FileNotFoundException e) {
			// TODO: handle exception
			e.printStackTrace();
		}catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally {
			obj.close();
			fout.close();
		}
		//reading objects from the file
		ObjectInputStream in = new ObjectInputStream(new FileInputStream(file));
		Object object=null;
		try { 
			while((object=in.readObject())!=null)
			{
				user=(User) object;
				System.out.println(user.getName() + "\t" + user.getMobileNo());
			}
		}catch (ClassNotFoundException e) {
			// TODO: handle exception
			
		}catch (EOFException e) {
			// TODO: handle exception
			
		}
		finally {
			in.close();
		}

	}

}
