package com.virtusa.shopping;

//package com.virtusa.shopping;



import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;

 

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;

 

public class AnnualReport {

 

    public static void main(String[] args) {
        File file= new File("com/virtusa/shopping/resources","annualreport2019.xlsx");
        Workbook workBook=null;
        if(!file.exists()) {
            try {
                file.createNewFile();
                System.out.println("File created");
            }catch(IOException ie) {
                ie.printStackTrace();
            }
        }else
        {
            workBook= new HSSFWorkbook();
            String[] names= {"Jan","Feb","Mar","Apr","May","Jun"};
            for(int i=0;i<names.length;i++) {
                workBook.createSheet(names[i]+"-19");
            }
            try {
                workBook.write(new FileOutputStream(file));
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

 

    }

 

}