package com.virtusa.shopping;

import java.io.Serializable;
import java.time.LocalDate;

public class User implements Serializable {
private long mobileNo;
private String name;
private LocalDate dob;
private transient long aadharCardNo;
public long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(long mobileNo) {
	this.mobileNo = mobileNo;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public LocalDate getDob() {
	return dob;
}
public void setDob(LocalDate dob) {
	this.dob = dob;
}
public long getAadharCardNo() {
	return aadharCardNo;
}
public void setAadharCardNo(long aadharCardNo) {
	this.aadharCardNo = aadharCardNo;
}

}
