package com.virtusa.banking.models;

public class User {

}
