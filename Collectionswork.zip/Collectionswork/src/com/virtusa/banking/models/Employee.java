package com.virtusa.banking.models;

import java.util.Date;

public class Employee {
 private int code;
 private String name;
 private String location;
 private Date doj;
 private int exp;
//public Employee(int i, String string, String string2, String string3, int j) {
	// TODO Auto-generated constructor stub
//}
public int getCode() {
	return code;
}
public void setCode(int code) {
	this.code = code;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public Date getDoj() {
	return doj;
}
public void setDoj(Date doj) {
	this.doj = doj;
}
public int getExp() {
	return exp;
}
public void setExp(int exp) {
	this.exp = exp;
}
 
}
