package com.virtusa.banking.models;

import java.util.PriorityQueue;
import java.util.Queue;

public class Queuedemo {
//	 public static void main(String[] args) 
//	  { 
//	    PriorityQueue<Employee> q = new PriorityQueue<Employee>(); 
//	    q.add(new Employee(1,"Ravi","hyd","09-09-09",22));
//	  
//	    for (int i=0; i<5; i++) 
//	     q.add(i); 
//	   
//	  //  q.add(e)
//	    System.out.println("Elements of queue-"+q); 
    
}
