package com.virtusa.banking.models;

import java.util.Scanner;

public class Question extends Thread {
	public void run()
	{
		while(true)
		{
			try
			{
				System.out.println("MCQ QUESTIONS");
				Thread.sleep(1000);
			}catch (InterruptedException e) {
				// TODO: handle exception
				break;
			}
		}
	}
	  public static void main(String args[]) {
 Question q = new Question();
 Scanner sc = new Scanner(System.in);
 String s = sc.nextLine();
 while(s!=null)
 q.interrupt();
}
}