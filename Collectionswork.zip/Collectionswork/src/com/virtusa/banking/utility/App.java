package com.virtusa.banking.utility;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

import com.virtusa.banking.models.Employee;
import com.virtusa.banking.models.EmployeeSorter;

public class App {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner = new Scanner(System.in);
Vector<Employee> employees = new Vector<Employee>();
Employee emp = null;
String doj = null;
Date date = null;
SimpleDateFormat ft = new SimpleDateFormat("dd-MM-YYYY");
for(int i=0;i<5;i++) {
	emp = new Employee();
	emp.setCode(new Random().nextInt(10000));
	System.out.println("Enter Name");
	emp.setName(scanner.nextLine());
	System.out.println("Enter doj");
	doj = scanner.nextLine();
	try {
		date = ft.parse(doj);
		emp.setDoj(date);
	}
	catch(ParseException e)
	{
		e.printStackTrace();
	}
	System.out.println("Enter location");
	emp.setLocation(scanner.nextLine());
	//add emp object to array list
	employees.add(emp);
	
}
//sort and print

//Lambda function
Collections.sort(employees,(e1,e2)->{
										return e1.getDoj().compareTo(e2.getDoj());
							}
						);
/**Collections.sort(employees, new EmployeeSorter());
for(Employee employee:employees) {
	System.out.println(employee.getName() + "\t");
    System.out.println(employee.getDoj().toString() + "\n");
	}
*/
Collections.sort(employees, new EmployeeSorter());
Enumeration<Employee> enumeration  = employees.elements();
Employee employee=null;
while(enumeration.hasMoreElements())
{
	employee=enumeration.nextElement();
System.out.println(employee.getName()+"\t");
System.out.println(employee.getDoj().toString()+"\n");


}

 

//calculate experience
Iterator<Employee> itr = employees.iterator();
Employee employee1=null;
while(itr.hasNext())
{
	
 employee1=itr.next();
//for(Employee employee : employees)
//{
	employee1.setExp(new Date().getYear()-employee1.getDoj().getYear()); 
	if(employee1.getExp()>15)
		System.out.println("15 years excellence goes to" + "\t" + employee1.getName());
	else if(employee1.getExp()>10&& employee1.getExp()<15)
		System.out.println("10 years experience goes  to " + "\t" + employee1.getName());
	else if(employee1.getExp()>15&& employee1.getExp()<10)
		System.out.println("5 years experience goes  to " + "\t" + employee1.getName());
	else
		System.out.println("Not eligible" + "\t" + employee1.getName());
		
	scanner.close();	
		
}


 
	}

}
