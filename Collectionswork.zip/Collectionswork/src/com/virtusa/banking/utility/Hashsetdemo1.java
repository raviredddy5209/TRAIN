package com.virtusa.banking.utility;

import java.util.HashSet;
import java.util.Scanner;

public class Hashsetdemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<String> indPlayers=new HashSet<String>();
        Scanner scanner=new Scanner(System.in);
		
		for(int i=0;i<5;i++)
		{
			System.out.println("Enter Indian Player names");
			indPlayers.add(scanner.nextLine());
		}
		HashSet<String> ozPlayers=new HashSet<String>();
        
		
		for(int i=0;i<5;i++)
		{
			System.out.println("Enter oz Player names");
			ozPlayers.add(scanner.nextLine());
		}
		//Union
		HashSet<String> iplPlayers=new HashSet<String>(indPlayers);
		iplPlayers.addAll(ozPlayers);
		System.out.println(iplPlayers);
	
		//intersection
		HashSet<String> iplPlayersint=new HashSet<String>(indPlayers);
		iplPlayersint.retainAll(ozPlayers); 
        System.out.println(iplPlayersint); 
        
        
	}}
        
         