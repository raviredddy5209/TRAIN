package com.virtusa.banking.utility;
import java.util.NavigableSet;
import java.util.TreeSet;
public class Treesetdemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
TreeSet<String> set = new TreeSet<String>();
	set.add("banana");
	set.add("citrus");
	
	set.add("apple");
	System.out.println(set);
	NavigableSet<String> n = set.descendingSet();
	System.out.println(n);
   NavigableSet<String> n1= set.headSet("banana",true);
	System.out.println(n1);
	NavigableSet<String> n2= set.tailSet("banana",true);
	System.out.println(n2);
	}

}
