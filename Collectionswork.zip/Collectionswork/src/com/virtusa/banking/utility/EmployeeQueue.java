package com.virtusa.banking.utility;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Scanner;

import com.virtusa.banking.models.Employee;
import com.virtusa.banking.models.EmployeeSorter;

public class EmployeeQueue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PriorityQueue<Employee> q = new PriorityQueue<Employee>(20, new EmployeeSorter()); 
		Scanner scanner = null;
		Employee emp = null;
		String doj = null;
		Date date = null;
		SimpleDateFormat ft = new SimpleDateFormat("dd-MM-YYYY");
		try {
			 scanner = new Scanner(System.in);
		
		for(int i=0;i<2;i++) {
			emp = new Employee();
			emp.setCode(new Random().nextInt(10000));
			System.out.println("Enter Name");
			emp.setName(scanner.nextLine());
			System.out.println("Enter doj");
			doj = scanner.nextLine();
			try {
				date = ft.parse(doj);
				emp.setDoj(date);
			}
			catch(ParseException e)
			{
				e.printStackTrace();
			}
			System.out.println("Enter location");
			emp.setLocation(scanner.nextLine());
			q.offer(emp);
			//employees.add(emp);
		}
		LinkedList<Employee> ll = new LinkedList<Employee>(q);
		System.out.println("enter search code");
		int empcode = scanner.nextInt();
		scanner.nextLine();
		Iterator<Employee> itr = ll.iterator();
		Employee employee = null;
		 while(itr.hasNext()){ 
			 employee = itr.next();
			 if(employee.getCode()==empcode)
			 {
				 System.out.println(employee.getName());
				 
			 }
		 }
		//retrieve data from priority queue
		while(!q.isEmpty()) {
			System.out.println(q.poll().getName());
		}
		}catch(NullPointerException np) {
			np.printStackTrace();
		}
		//sort and print
		 

		//calculate experience
		 


	}

}
