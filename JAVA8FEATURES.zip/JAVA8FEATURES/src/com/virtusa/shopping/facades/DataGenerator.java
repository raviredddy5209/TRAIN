package com.virtusa.shopping.facades;

import java.util.Random;

public interface DataGenerator {
	public static int getOTP()
	{
		return new Random().nextInt(1000000);
	}

}
