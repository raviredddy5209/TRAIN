package com.virtusa.shopping.facades;

 @FunctionalInterface
public interface Greeting {
	 String wish(String name);

}
