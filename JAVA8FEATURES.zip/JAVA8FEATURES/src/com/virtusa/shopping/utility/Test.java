package com.virtusa.shopping.utility;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ForkJoinPool;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
//		int arrInput[] = { 21, 0, 8, -12 };
//		int arrOutput[];
//		arrOutput = new int[4];
//		for (int i = 0; i < arrInput.length; i++) {
//		int resultArray = arrInput[i] * 3;
//		arrOutput[i] = resultArray;
//		
//		}
//		for (int show : arrOutput) {
//			System.out.print(" "+show);
//			}
		List<Integer> list=Arrays.asList(1,2,3);
		int res = list.stream().reduce(6,(s1,s2)-> s1*s2,(p,q)->p+q);
		System.out.println(res);
		
		ForkJoinPool commonpool = ForkJoinPool.commonPool();
		System.out.println("Parallel" + commonpool.getParallelism());
		Double[] unsorted = new Double[10000000];
		for(int i=0;i<unsorted.length;i++)
		{
			unsorted[i] = random(i,unsorted.length);
		}
		long start = System.currentTimeMillis();
		Arrays.sort(unsorted);
		long end= System.currentTimeMillis();
		System.out.println("time : "  + (end - start)+ "ms.");
		unsorted = new Double[1000000];
		for(int i=0;i<unsorted.length;i++)
		{
			unsorted[i] = random(i,unsorted.length);
		}
	}
		private static Double random(int i , int length )
		{
			return Math.random() * i%length;
		}
			
		
//		long startTime = System.nanoTime();
//		List<Integer> list=Arrays.asList(1,2,3);
//		int res = list.stream().reduce(6,(s1,s2)-> s1*s2,(p,q)->p+q);
//		System.out.println(res);
//		
//		long endTime   = System.nanoTime();
//		long totalTime = endTime - startTime;
//		System.out.println(totalTime);
		
	}


