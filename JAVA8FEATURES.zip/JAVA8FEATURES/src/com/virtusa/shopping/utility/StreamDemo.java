package com.virtusa.shopping.utility;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.virtusa.shopping.models.Product;

public class StreamDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//chain of operations
		ProductManager.getProducts().stream().filter(p->p.getCost()>5000)
		.map(p->p.getName()).forEach(System.out::println);
		
		//collect
		List<String> names = ProductManager.getProducts().stream().filter(p->p.getCost()>10000).
			    map(p->p.getName()).collect(Collectors.toList());
			   
	       
		//sort the product on dop
		ProductManager.getProducts().stream().map(p->p.getDop()).sorted()
        .forEach(System.out::println);
		//sort on object
	/**	List<Product> products = ProductManager.getProducts().stream()
		.sorted((p1,p2)->{return p1.getName().compareTo(p2.getName());})
		.collect(Collectors.toList());
		for(Product product : products)
		{
			System.out.println(product.getName()+"\t"+product.getCost());
		} */
		
		
		
	/**	List<Product> products = ProductManager.getProducts().stream()
				.sorted((p1,p2)->{return p1.getDop().compareTo(p2.getDop());})
				.collect(Collectors.toList());
				for(Product product : products)
				{
					System.out.println(product.getName()+"\t"+product.getDop());
				}
				*/
		
		List<Product> products = ProductManager.getProducts().stream()
				.sorted((p1,p2)->{
					if(p1.getCost()>p2.getCost())
						return 1;
					else if(p1.getCost()<p2.getCost())
						return -1;
					else 
						return 0;
				})
				
				.collect(Collectors.toList());
				for(Product product : products)
				{
					System.out.println(product.getName()+"\t"+product.getCost());
				}
		
				//Optional-used to avoid NULL pointer exceptions
		        List<Product> filteredProducts = ProductManager.getProducts().stream().
		                filter(p->p.getName().startsWith("L"))
		                .collect(Collectors.toList());
		       
		       Optional <Product> product=filteredProducts.stream().findFirst();
		       //if(product.isPresent())
		    	    
		       //Predicate
		       Predicate<LocalDate> predicate=(date)->{
		        	return date.isBefore(LocalDate.now());
		        };
		        System.out.println(ProductManager.getProducts().stream().map(p->p.getDop()).allMatch(predicate));
		       
		        //System.out.println(ProductManager.getProducts().stream().map(p->p.getDop()).anyMatch(predicate));
			    
		      //count  
		        System.out.println(ProductManager.getProducts().stream()
		        		.filter(p->p.getCost()>10000).
		        count());
		        //distinct
		        ProductManager.getProducts().stream()
		        		.filter(p->p.getCost()>10000).
		        distinct().map(p->p.getName()).forEach(System.out::println);
		       
	}

}
