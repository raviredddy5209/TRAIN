package com.virtusa.shopping.utility;

import java.time.LocalDateTime;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.chrono.JapaneseChronology;
import java.time.chrono.JapaneseDate;
import java.time.chrono.JapaneseEra;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class DateTimeAPIDemo {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        System.out.println(ZoneId.getAvailableZoneIds());
        ZoneId zone1=ZoneId.of("Asia/Kolkata");
        LocalDateTime localDateTime=LocalDateTime.now(zone1);
        System.out.println("India\t"+localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss.SSS a")));
        
        ZoneId zone2=ZoneId.of("Atlantic/Jan_Mayen");
        LocalDateTime local2=LocalDateTime.now(zone2);
        System.out.println("Atlantic\t"+local2.format(DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm:ss.SSS a")));
        //conversion
        ZonedDateTime newTime = ZonedDateTime.now(ZoneId.of("Asia/Singapore"));
       // System.out.println("Zoned date time : "+newTime.getChronology());
        System.out.println(newTime.toString());
        //add month or year to current date
        Period p1=Period.of(5,0,0);
        System.out.println("Future Date in Year"+LocalDateTime.now().plus(p1).toString());
        System.out.println("Future Date In month"+LocalDateTime.now().plus(5,ChronoUnit.MONTHS));
        JapaneseEra[] japanesecalender= JapaneseEra.values();
        for(JapaneseEra era: japanesecalender)
        {
        	System.out.println(era.toString());
        	int firstYear = (era==JapaneseEra.MEIJI)?6:1;//Until Era supports range(YEAR_OF_ERA)
        	 JapaneseDate hd1=Japane890useChronology.INSTANCE.dateYearDay(era, firstYear, 1);
             System.out.println(hd1); 
        }
        
    
    }
}
