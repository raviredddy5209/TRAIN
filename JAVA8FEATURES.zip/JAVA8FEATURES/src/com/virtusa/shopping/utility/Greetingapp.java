package com.virtusa.shopping.utility;

import com.virtusa.shopping.facades.Greeting;

public class Greetingapp {

	public static void main(String[] args) {
		 			
	    Greeting greeting=(name)->{
	            return "Hi!!"+name+"all the best......";
	        };														
	       
	        System.out.println(greeting.wish("Srujana "));

	}

}
																						

	

					
									