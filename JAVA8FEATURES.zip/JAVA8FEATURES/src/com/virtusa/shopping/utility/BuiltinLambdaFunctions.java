package com.virtusa.shopping.utility;

import java.time.LocalDate;
import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import com.virtusa.shopping.facades.DataGenerator;

 

public class BuiltinLambdaFunctions {

 

    public static void main(String[] args) {
        // TODO Auto-generated method stub

 

      String[] arr= {"puppy","subbu"};
        Function<String,String> greeting=(name)->{
            return "Hi!!  "+name+"\n Rock lambdas....";
        };
        //invoke
        System.out.println(greeting.apply("Subbu"));
        
        Function<Integer, Integer> countFunction=(count)->
        {
            return new Random().nextInt(count);
        };
        //invoke
        System.out.println(countFunction.apply(100));
        
        Function<String[], Integer> names=(arrNames)->
        {
                return arrNames.length;
        };
        //invoke
        System.out.println(names.apply(arr));
        
        //Bifunction
        BiFunction<Integer, Integer, Boolean> compare=(x,y)->
        {
            return x>y;
        };
        //invoke
        System.out.println(compare.apply(45, 67));
        
        BiFunction<String[], String, String> join=(data,delimiter)->
        {
            String result=" ";
            for(String s : data)
            {
                result+=(s+delimiter);
            }
            return result;
        };
        String[] name= {"Swarna","Subbu"};
        //invoke
        System.out.println(join.apply(name, "--->"));
        //predicate
        Predicate<LocalDate> check=(date)->{
        	return date.isBefore(LocalDate.now());
        };
        
       //Invoke
        System.out.println(check.test(LocalDate.now().minusMonths(5)));
        //Bipredicate
        BiPredicate<String,String> existence=(message,search)->{
        	return message.contains(search);
        };
        //invoke
        System.out.println(existence.test("Core java","core"));
        //consumer
        Consumer<StringBuilder[]> reverse=(data)->{
        	for(StringBuilder s : data)
        	{
        		System.out.println(s.reverse());
         	}
        }; 
        StringBuilder[] nameList=new StringBuilder[2];
        nameList[0] = new StringBuilder("HCL");
        nameList[1] = new StringBuilder("WIPRO");
        reverse.accept(nameList);
        //Supplier
        Supplier supplier = DataGenerator::getOTP;
        System.out.println(supplier.get());
        
        
    }
}
 
