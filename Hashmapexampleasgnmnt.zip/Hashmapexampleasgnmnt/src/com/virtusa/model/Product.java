package com.virtusa.model;

import java.time.LocalDate;

public class Product {
private int prodno;
private String ProdName;
private long cost;
 private LocalDate dop;
private int quantity;
public int getProdno() {
	return prodno;
}
public void setProdno(int prodno) {
	this.prodno = prodno;
}
public String getProdName() {
	return ProdName;
}
public void setProdName(String prodName) {
	ProdName = prodName;
}
public long getCost() {
	return cost;
}
public void setCost(long cost) {
	this.cost = cost;
}
public LocalDate getDop() {
	return dop;
}
public void setDop(LocalDate dop) {
	this.dop = dop;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}

}
 
 