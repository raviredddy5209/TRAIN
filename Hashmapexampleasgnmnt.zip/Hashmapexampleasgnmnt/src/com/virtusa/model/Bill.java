package com.virtusa.model;

import java.time.LocalDate;
import java.util.List;

public class Bill {
	private List<Prodqty> prodqty;
	private LocalDate billDate;
	 private long billamt;
	public List<Prodqty> getProdqty() {
		return prodqty;
	}
	public void setProdqty(List<Prodqty> prodqty) {
		this.prodqty = prodqty;
	}
	public LocalDate getBillDate() {
		return billDate;
	}
	public void setBillDate(LocalDate billDate) {
		this.billDate = billDate;
	}
	public long getBillamt() {
		return billamt;
	}
	public void setBillamt(long billamt) {
		this.billamt = billamt;
	}
	 
}
