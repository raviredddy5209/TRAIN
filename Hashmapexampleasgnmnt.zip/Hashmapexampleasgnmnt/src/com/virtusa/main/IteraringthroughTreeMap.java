package com.virtusa.main;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class IteraringthroughTreeMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<String,Double> hm = new TreeMap<String,Double>();
		//adding elements to map
		hm.put("Jerry",new Double(10000.00));
		hm.put("Cat",new Double(10000.22));
		hm.put("Mary",new Double(1040.00));
		hm.put("Reddy",new Double(10220.00));
		//Get a set of the entries
		Set<Map.Entry<String,Double>> set = hm.entrySet();
		//get an iterartor
		Iterator<Map.Entry<String,Double>> i  = set.iterator();
		//displaying elements
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		

	}

}
