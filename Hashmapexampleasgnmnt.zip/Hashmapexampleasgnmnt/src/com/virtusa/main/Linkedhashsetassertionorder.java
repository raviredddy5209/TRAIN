package com.virtusa.main;

import java.util.LinkedHashMap;
import java.util.Map;

public class Linkedhashsetassertionorder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Map<Integer, String> cache = new LinkedHashMap<Integer,String>(10,0.75f,true);
    	cache.put(4, "D");
    	cache.put(1, "A");
    	cache.put(5, "E"); 
    	cache.put(3, "C");
    	cache.put(2, "B");
    	System.out.print("Not accessed yet " + cache);
    	cache.get(1);
    	cache.get(5);
    	cache.get(3);
    	System.out.print("\n Linked hash map after accesing some elemsnts \n " + cache);
    	cache.get(2);
    	cache.put(6, "F");
    	System.out.print("\n Linked hash map after accesing and adding new entry " + cache);
    	
	}

}
