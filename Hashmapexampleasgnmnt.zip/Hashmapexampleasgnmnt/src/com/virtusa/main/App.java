package com.virtusa.main;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import com.virtusa.model.Bill;
import com.virtusa.model.Prodqty;
import com.virtusa.model.Product;

public class App {
	public static List<Product> getproducts(){
		List<Product> products = new ArrayList<Product>();
		Product product=null;
	 
		for(int i=0;i<100;i++)
		{
			product = new Product();
			product.setProdno(new Random().nextInt(100));
			product.setProdName("Product" + i);
			product.setDop(LocalDate.now().minusDays(180-i));
			product.setCost(new Random().nextInt(1000));
			products.add(product);
		}
		 return products;
	}
      public static List<Bill> getBills()
      {
    	  long sum=0;
    	  Prodqty prodqty=null;
    	  List<Prodqty> pqs = null;
    	  int length = 0;
    	  //generate 50 bills
    	  List<Bill> bills = new ArrayList<Bill>();
    	  
    	  for(int i=0;i<50;i++) {
    		  //number of products per bill
    		  Bill bill = new Bill();
    		  pqs = new ArrayList<Prodqty>();
    		  length = new Random().nextInt(15);
    		  for(int j=0;j<length;j++)
    		  {
    			  prodqty= new Prodqty();
    			  prodqty.setProduct(getproducts().get(new Random().nextInt(95)));
    			  prodqty.setQty(new Random().nextInt(5));
    			  //pickup the price for the chosen product
    			  prodqty.setAmount(prodqty.getProduct().getCost()*prodqty.getQty());
    			  pqs.add(prodqty);
    			  sum = sum +   prodqty.getAmount();
    		  }
    		  bill.setBillDate(LocalDate.now().minusDays(55));
    		  bill.setProdqty(pqs);
    		  bill.setBillamt(sum);
    		  bills.add(bill);
    	  }
    	  return bills;
    	
      }
	public static void main(String[] args) {
		// TODO Auto-generated method stub  new ills = 
		Hashtable<Integer,Bill> htbills = new Hashtable<Integer,Bill>();
		//add bills to it
		for(Bill bill : getBills())
		
			htbills.put(new Random().nextInt(10000), bill);
		
		//print all the keys
	/**Enumeration<Integer> enumeration =	htbills.keys();
/**	while(enumeration.hasMoreElements())
	{
		System.out.println(enumeration.nextElement());
	}*/
	
	
			//print all the bills with bill no
		/**	for(Bill bill : htbills.values())
			{
				System.out.println(bill.getBillDate()+ "\t" + bill.getBillamt());
				while(enumeration.hasMoreElements())
				{
					System.out.println(enumeration.nextElement());
				}
			}
	/*	Set set = htbills.keySet();Iterator<E> itr =set.iterator();
			while(itr.hasNext())
			{
				billNo = (int) itr.next();
				htbills.get(billNo);
			} */
		
			
			Set set =htbills.entrySet();
			Iterator itr = set.iterator();
			while(itr.hasNext()) {
				Map.Entry<Integer,Bill> entry = (Map.Entry<Integer,Bill>) itr.next();
				System.out.println("********************************************");
				System.out.println("Bill No" + entry.getKey());
				System.out.println("Bill Date "  + entry.getValue().getBillDate());
				System.out.println("********************************************");
				for(Prodqty pq : entry.getValue().getProdqty())
				{
					System.out.println(pq.getProduct().getProdName()  + "\t");
					System.out.println(pq.getQty() + "\t");
					System.out.println(pq.getAmount() + "\n");
					System.out.println("********************************************");
					
				}System.out.println("Total bill amount " + entry.getValue().getBillamt());
				System.out.println("********************************************");
				
				
				
				
				
			}
		}
	}


