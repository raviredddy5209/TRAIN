package com.virtusa.main;

import java.util.TreeMap;

public class TreeMapdemoex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<String,Double> hm = new TreeMap<String,Double>();
		//adding elements to map
		hm.put("Tomato",new Double(10000.00));
		hm.put("potato",new Double(10000.22));
		hm.put("Onion",new Double(1040.00));
		hm.put("Cabbage",new Double(1040.00));
		//hm.put("Reddy",new Double(10220.00));
		System.out.println(hm);
		System.out.println(hm.headMap("Onion"));
		System.out.println(hm.tailMap("Onion"));
		System.out.println(hm.subMap("Cabbage", "potato" ));
		Thread
		
	}

}
