package com.virtusa.banking.utility.demo;

import java.util.HashSet;
import java.util.Scanner;

import com.google.common.collect.Sets;

public class setDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/**HashSet<String> ind = new HashSet<>();
		
		// Adding elements in HashSet
		ind.add("Kohli");
		ind.add("Dhoni");
		ind.add("Raina");
		ind.add("bumrah");
		ind.add("rohit");
		ind.add("bhuvi");
		ind.add("chahal");
		ind.add("yadav");
		ind.add("shami");
		ind.add("saran");
		ind.add("ravi");
		
		System.out.println("Indian team  = " + ind);
		
		 
		HashSet<String> pak = new HashSet<>();
		
		
		pak.add("sarfraz");
		pak.add("fakhar");
		pak.add("malik");
		pak.add("akthar");
		pak.add("wasim");
		pak.add("ali");
		pak.add("raghu");
		pak.add("inzi");
		pak.add("saed"); 		 
		pak.add("anwar");
		pak.add("amir");
	
		System.out.println("pak team = " + pak);
   
		 ind.retainAll(ind);
		boolean b = ind.addAll(pak);
				
		if(b)
		{
			System.out.println("Merging of Set 1 & Set 2 Successfull");
		}
		
		System.out.println("league team = " + ind);
		
	
  
			*/	HashSet<String> indPlayers=new HashSet<String>();
		        Scanner scanner=new Scanner(System.in);
				
				for(int i=0;i<5;i++)
				{
					System.out.println("Enter Indian Player names");
					indPlayers.add(scanner.nextLine());
				}
				HashSet<String> ozPlayers=new HashSet<String>();
		        
				
				for(int i=0;i<5;i++)
				{
					System.out.println("Enter oz Player names");
					ozPlayers.add(scanner.nextLine());
				}
				//Union
				HashSet<String> iplPlayers=new HashSet<String>(indPlayers);
				iplPlayers.addAll(ozPlayers);
				System.out.println(iplPlayers);
			
				//intersection
				HashSet<String> Worldcupplayers=new HashSet<String>(indPlayers);
				Worldcupplayers.add("ms"); 
				Worldcupplayers.add("kohli"); 
				Worldcupplayers.add("a"); 
				Worldcupplayers.add("b"); 
				Set intersection = Sets.intersection(gset, Worldcupplayers);
				//iplPlayers.retainAll(Worldcupplayers );
		        System.out.println(Worldcupplayers); 
		        //System.out.println(indPlayers); 
		    	
		        //difference
//		        Set〈Integer〉 difference = new HashSet〈Integer〉(a); 
//		        difference.removeAll(b); 
//		        System.out.print("Difference of the two Set"); 
//		        System.out.println(difference); 
			}

	}

