package com.vir.threaddemo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.virtusa.banking.models.Answer;
import com.virtusa.banking.models.MCQ;
import com.virtusa.banking.models.Question;

public class MCQAPP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Question> questionList = new ArrayList<Question>();
		Question question = new Question();
		question.setQsnno(1);
		question.setDescription("Capital of srilanka ?");
		List<Answer> answerList = new ArrayList<Answer>();
		Answer answer = new Answer();
		answer.setAnsno(1);
		answer.setAnsdesc("colombo");
		answerList.add(answer);
		  answer=new Answer();
		answer.setAnsno(2);
		answer.setAnsdesc("madagascar");
		answerList.add(answer);
		  answer=new Answer();
		
		answer.setAnsno(3);
		answer.setAnsdesc("maharashtra");
		answerList.add(answer);
		  answer=new Answer();
		
		answer.setAnsno(4);
		answer.setAnsdesc("Trivandrum");
		answerList.add(answer);
		  answer=new Answer();

		question.setAnslist(answerList);
		questionList.add(question);
		//second question
		 //second question

		   question=new Question();

		   question.setQsnno(2);

		   question.setDescription("Full Form of CPU?");	

		   answerList=new ArrayList<Answer>();

		   answer=new Answer();

		   answer.setAnsno(1);

		   answer.setAnsdesc("Core Processing Unit");

		   answerList.add(answer);

		   answer=new Answer();

		   answer.setAnsno(2);

		   answer.setAnsdesc("Core Processor Unit");	   

		   answerList.add(answer);

		   answer=new Answer();

		   answer.setAnsno(3);

		   answer.setAnsdesc("Central Processing Unit");

		   answerList.add(answer);

		   answer=new Answer();

		   answer.setAnsno(4);

		   answer.setAnsdesc("Central Processot Unit");

		   answerList.add(answer);
 
		   question.setAnslist(answerList);

		   questionList.add(question);
 
		   //create Thread

		   MCQ mcq=new MCQ(questionList);

		   mcq.start();
		   Scanner scanner = new Scanner(System.in);
		   String input = scanner.nextLine();
		   if(input!=null)
		   mcq.interrupt();

		 

	}

}
