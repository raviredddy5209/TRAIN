package com.virtusa.banking.models;

import java.util.List;

import com.virtusa.banking.models.Answer;
import com.virtusa.banking.models.Question;

public class MCQ extends Thread {
private List<Question> questionlist;

	public MCQ(List<Question> questionlist) {
	super();
	this.questionlist = questionlist;
}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//super.run();
		for(Question ques : questionlist)
		{
			System.out.println(ques.getQsnno() + "\t" + ques.getDescription());
			for(Answer ans : ques.getAnslist())
			{
				System.out.println(ans.getAnsno() + "\t" + ans.getAnsdesc());
			}
			try
			{
				Thread.sleep(100000);
			}catch (InterruptedException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}

}
