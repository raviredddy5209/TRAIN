package com.virtusa.banking.models;

public class Answer {
private int ansno;
private String ansdesc;
public int getAnsno() {
	return ansno;
}
public void setAnsno(int ansno) {
	this.ansno = ansno;
}
public String getAnsdesc() {
	return ansdesc;
}
public void setAnsdesc(String ansdesc) {
	this.ansdesc = ansdesc;
}
 
}
