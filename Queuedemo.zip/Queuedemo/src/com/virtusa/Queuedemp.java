package com.virtusa;

public class Queuedemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue 

	}

}
