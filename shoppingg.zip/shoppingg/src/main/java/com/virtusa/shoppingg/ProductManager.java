package com.virtusa.shoppingg;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.virtusa.shopping.models.Product;

public class ProductManager {

	
	public static List<Product> getProducts()
    {
        List<Product> products=new ArrayList<Product>();
        Product product=null;
        for(int i=0;i<100;i++)
        {
            product=new Product();
            product.setProductNo(new Random().nextInt(100));
            product.setName("Product"+i);
            product.setDop(LocalDate.now().minusDays(180-i));
            product.setCost(new Random().nextInt(10000));
            products.add(product);
        

 

        }
        return products;
    }
	public static List<String> getProductNames()
	{
		List<String> productNames = new ArrayList<String>();
		for(Product product:getProducts())
			productNames.add(product.getName());
		return productNames;
	}
}
