package com.virtusa.shopping.models;

import java.time.LocalDate;

public class Product {
    private int productNo;
    private String name;
    private LocalDate dop;
    private long cost;
    public int getProductNo() {
        return productNo;
    }
    public void setProductNo(int productNo) {
        this.productNo = productNo;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public LocalDate getDop() {
        return dop;
    }
    public void setDop(LocalDate dop) {
        this.dop = dop;
    }
    public long getCost() {
        return cost;
    }
    public void setCost(long cost) {
    	if(cost<0)
    		throw new IllegalArgumentException("Cost should be positive only");
    	else
        this.cost = cost;
    }
    
}


