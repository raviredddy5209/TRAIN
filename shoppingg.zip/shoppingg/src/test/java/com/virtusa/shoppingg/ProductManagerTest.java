package com.virtusa.shoppingg;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.junit.Assert.assertThat;
import static 
import java.util.Collections;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.Test;
//import static org.hamcrest.core.Is.*;
public class ProductManagerTest {
	//test for product existence
	@Test
	public void testGetProduct()
	{
	//	assertThat(ProductManager.getProducts(),hasItem(new Product()));
		assertThat(ProductManager.getProductNames(),hasItem( "Product0"));
	}
	//test for products existence
	
	@Test
	public void testGetProducts()
	{
	 
		assertThat(ProductManager.getProductNames(),hasItems( "Product0","Product77"));
	}
	@Test
	public void testSortedProducts() {
		assertThat(ProductManager.getProductNames(), is(emptyIterableOf(String.class)));
		List<String> result = ProductManager.getProductNames();
		Collections.sort(result);
		assertThat(result, Matchers.<String> iterableWithSize(100)); 
		assertThat(result,containsInAnyOrder(ProductManager.getProductNames()));
	}
	

}
