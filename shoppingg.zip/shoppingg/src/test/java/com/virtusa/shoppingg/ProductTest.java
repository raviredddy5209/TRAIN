package com.virtusa.shoppingg;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collection;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import static org.junit.Assert.assertThat;
import com.virtusa.shopping.models.Product;
import static org.hamcrest.core.Is.*;
import static org.hamcrest.CoreMatchers.notNullValue;
@RunWith(value=Parameterized.class)
public class ProductTest {
	private static  Product product;
	@Parameter(value=0)
	public int id;
	@Parameter(value=1)
	public String pname;
	@Parameter(value=2)
	public long pcost;
	@Parameter(value=3)
	public LocalDate pdop;
	
	@Parameters
	public static Collection getTestParameters() {
	    return Arrays.asList(new Object[][] {{2312,"Laptop",34234,LocalDate.of(2017, 2, 2)},
	        {2314,"Note",234566,LocalDate.of(2018, 2, 2)}
	    });}
	    
	@BeforeClass
	public static void createInstance()
	{
		product=new Product();
	}
  @Before
	public void initializeproduct()
	{
//		product.setProductNo(4838);
//		product.setName("Laptop");
//		product.setDop(LocalDate.of(2018, 2, 27));
//		product.setCost(43859);
		product.setProductNo(id);
		product.setName(pname);
		product.setDop(pdop);
		product.setCost(pcost);
	  
	}
  
  
  
  
  @Test(expected=IllegalArgumentException.class)
  public void testproductCost()
  {
	  product.setCost(-43858);
  }
  
	@Test
	public void testproductDOP()
	{
	// Assert.assertTrue(product.getDop().isBefore(LocalDate.now()));
	//hamcrest
		 
		  assertThat(true, is(product.getDop().isBefore(LocalDate.now())));
	}
	@AfterClass
	public static void deleteInstance()
	{
		product = null;
	}
	 @Test
	    public void testProductName()
	    {
	        //Assert.assertNotNull(product.getName());
		 //hamcrest
		 assertThat(product.getName(),is(notNullValue()));
	    }

}
