package com.virtusa.banking.thread;

public class app {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Anim ani = new Anim("RAVI","Userthread");
    ani.start();
   // Thread.activeCount();
    //runnable with lambda function
    Runnable runnable = ()-> {
    	for(int i=0;i<10;i++)
    	{
    		System.out.println(Thread.currentThread().getName() + "-->"+ i);
    	}
    };
    new Thread(runnable).start();
	}

}
