package com.virtusa.banking.thread;

import java.util.List;

import com.virtusa.banking.thread.Answer;
import com.virtusa.banking.thread.Question;

public class MCQ extends Thread {
private List<Question> questionlist;

	public MCQ(List<Question> questionlist) {
	super();
	this.questionlist = questionlist;
}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//super.run();
		for(Question ques : questionlist)
		{
			System.out.println(ques.getQsnno() + "\t" + ques.getDescription());
			for(Answer ans : ques.getAnslist())
			{
				System.out.println(ans.getAnsno() + "\t" + ans.getAnsdesc());
			}
			try
			{
				Thread.sleep(1000);
			}catch (InterruptedException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}

}
