package com.virtusa.banking.thread;

import java.util.List;
import java.util.Scanner;

public class Question extends Thread {
	private int qsnno;
	private String description;
	private List<Answer> anslist;
	private int crtans;
	public int getQsnno() {
		return qsnno;
	}
	public void setQsnno(int qsnno) {
		this.qsnno = qsnno;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Answer> getAnslist() {
		return anslist;
	}
	public void setAnslist(List<Answer> anslist) {
		this.anslist = anslist;
	}
	public int getCrtans() {
		return crtans;
	}
	public void setCrtans(int crtans) {
		this.crtans = crtans;
	}
 
}