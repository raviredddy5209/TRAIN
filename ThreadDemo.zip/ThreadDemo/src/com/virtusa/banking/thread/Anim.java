package com.virtusa.banking.thread;

public class Anim extends Thread {
	private String username,Threadname;

	public Anim(String username, String threadname) {
		super();
		this.username = username;
		Threadname = threadname;
		this.setName(threadname);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		System.out.println(Thread.currentThread().getName());
		for(char ch : this.username.toCharArray())
		{
			System.out.println(ch);
			//Thread.activeCount();
			try
			{
				Thread.sleep(2000);
			}catch (InterruptedException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
		
		
		
		
		
	}
	
	

}
