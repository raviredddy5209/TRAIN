package com.virtusa.banking.thread;

public class Customer extends Userthread implements Runnable {
public Customer() {
	// TODO Auto-generated constructor stub
	super();
}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName());
	}

}
