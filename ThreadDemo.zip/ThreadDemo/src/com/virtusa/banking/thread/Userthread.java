package com.virtusa.banking.thread;

public class Userthread {
private String Name;
private int age;
private String email;

public Userthread(String name, int age) {
	super();
	Name = name;
	this.age = age;
	//this.email = email;
}
 
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}

public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}

}
