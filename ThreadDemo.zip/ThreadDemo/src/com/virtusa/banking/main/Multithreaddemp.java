package com.virtusa.banking.main;

import com.virtusa.banking.thread.Customer;
import com.virtusa.banking.thread.Userthread;

public class Multithreaddemp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread[] threads = new Thread[10];
		Userthread ut = new Userthread("Ravi",21);
		for( int i=0;i<threads.length;i++)
		{
			threads[i] = new Thread(new Customer(), "Customer"+i);
			threads[i].start();
		}

	}

}
