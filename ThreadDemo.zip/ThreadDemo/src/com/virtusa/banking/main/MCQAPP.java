package com.virtusa.banking.main;

import java.util.ArrayList;
import java.util.List;

import com.virtusa.banking.thread.Answer;
import com.virtusa.banking.thread.Question;

public class MCQAPP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Question> questionList = new ArrayList<Question>();
		Question question = new Question();
		question.setQsnno(1);
		question.setDescription("Capital of srilanka ?");
		List<Answer> answerList = new ArrayList<Answer>();
		Answer answer = new Answer();
		answer.setAnsno(1);
		answer.setAnsdesc("colombo");
		answerList.add(answer);
		answer.setAnsno(2);
		answer.setAnsdesc("madagascar");
		answerList.add(answer);
		
		answer.setAnsno(3);
		answer.setAnsdesc("maharashtra");
		answerList.add(answer);
		
		answer.setAnsno(4);
		answer.setAnsdesc("Trivandrum");
		answerList.add(answer)
;
		question.setAnslist(answerList);
		questionList.add(question);
		//second question
		

	}

}
