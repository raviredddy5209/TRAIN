package com.virtusa.banking.utility;

public class Bankingapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("gdjgk");
	}

}
