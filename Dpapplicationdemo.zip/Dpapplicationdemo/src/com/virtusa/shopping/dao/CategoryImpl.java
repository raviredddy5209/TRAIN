package com.virtusa.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import java.sql.Statement;


import com.virtusa.shopping.helpers.MySqlHelper;
import com.virtusa.shopping.models.Category;

public class CategoryImpl  implements CategoryDao{
	private Connection conn;
	private Statement statement;
	private ResultSet resultset;
	private ResourceBundle rb;
	 private List<Category> categoryList ;
	 private Category category;
	 private PreparedStatement pre;
	// PreparedStatement pre = new PreparedStatement(conn, catalog)
	public CategoryImpl() {
		rb = ResourceBundle.getBundle("com/virtusa/shopping/resource/db");
		categoryList = new ArrayList<Category>();
	}
	@Override
	public void addCategory(Category category) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCategory(Category category) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCategory(int categoryId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Category> getCategories() throws SQLException {
		// TODO Auto-generated method stub
		conn=MySqlHelper.getConnection(); 
		String query=rb.getString("getcategories"); 
		 
		try {
			statement=conn.createStatement();
			resultset=statement.executeQuery(query);
			while(resultset.next())
			{
			      category = new Category();
			      category.setCatId(resultset.getInt(1));
			      category.setCatName(resultset.getString(2));
			      categoryList.add(category);
			}
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally {
			conn.close();
		}
		return categoryList;
	}
	@Override
    public int[] addAllCategory(List<Category> categories) throws SQLException  {
        // TODO Auto-generated method stub
        conn=MySqlHelper.getConnection();
        int[] records= {};
        String query=rb.getString("add");
        Savepoint savepoint = null;
        
        try {
            pre=conn.prepareStatement(query);
            for(Category category:categories) {
               
                pre.setInt(1, category.getCatId());
                pre.setString(2, category.getCatName());
                pre.addBatch();
                savepoint=conn.setSavepoint();
              //  pre.setInt(parameterIndex, x);
               
            }
        records=pre.executeBatch();
        }
        catch (SQLException e) {
            // TODO: handle exception
            e.printStackTrace();
        }
        finally
        {
            conn.close();
        }
        return records;
    }
	@Override
	public Category getCateggoryById(int catId) throws SQLException {
		// TODO Auto-generated method stub
		conn = MySqlHelper.getConnection();
		String query=rb.getString("getcategorybyid");
		try {
		pre=conn.prepareStatement(query);
		pre.setInt(1,catId);
		resultset = pre.executeQuery();
		resultset.next();
		category= new Category();
		category.setCatId(resultset.getInt(1));
		category.setCatName(resultset.getString(2));
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			conn.close();
		}

return category;
		//return null;
	}
}
