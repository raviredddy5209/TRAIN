package com.virtusa.shopping.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLType;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.ResultSetMetaData;
import com.virtusa.shopping.helpers.MySqlHelper;
import com.virtusa.shopping.models.Product;

public class ProductImpl implements ProductDao{

	private Connection conn;
	private CallableStatement callable;
	private ResultSet resultset;
	private java.sql.ResultSetMetaData  metadata;
	@Override
	public int addProduct(Product product) throws SQLException {
		// TODO Auto-generated method stub
		conn = MySqlHelper.getConnection();
		conn.setAutoCommit(false);
		int count=0;
		//Date date=null;
		try {
			callable=conn.prepareCall("{call addproduct(?,?,?,?,?)}");
			callable.setInt(1,product.getProdId());
			callable.setString(2, product.getProdName());
			callable.setDate(3,product.getDop());
			callable.setInt(4,product.getCost());
			callable.setInt(5, product.getCategory().getCatId());
			count = callable.executeUpdate();
			conn.commit();
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
			conn.rollback();
		}finally {
			conn.close();
		}return count;
		
	}

	@Override
	public List<Object[]> getproducts() throws SQLException {
		// TODO Auto-generated method stub
	conn = MySqlHelper.getConnection();
	List<Object[]> objects = new ArrayList<Object[]>();
	//Object[] object=null;
	try {
		callable=conn.prepareCall("{call getallproducts()}");
		resultset = callable.executeQuery();
		metadata = resultset.getMetaData();
		//Object[] object = new  Object[metadata.getColumnCount()];

		while (resultset.next()) {
        Object[] object = new  Object[metadata.getColumnCount()];

			for(int i=0;i<metadata.getColumnCount();i++)
			{
				//object[] object = new  Object[metadata.getColumnCount()];

				object[i] = resultset.getObject(i+1);
			}
			objects.add(object);
			
		}
	}catch (SQLException e) {
		// TODO: handle exception
		e.printStackTrace();
	}
		return objects;
	}

	@Override
	public Product getproductById(int prodId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int countproducts(String catName) throws SQLException {
		// TODO Auto-generated method stub
		conn=MySqlHelper.getConnection();
		int count = 0;
		try {
			callable=conn.prepareCall("{call countProductsBycategory(?,?)}");
			callable.setString(1, catName);
			callable.setInt(2, count);
			callable.registerOutParameter(2, java.sql.Types.INTEGER);
			callable.execute();
		    count=callable.getInt(2);
		
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally {
			conn.close();
			}
		return count;
	}
	

}
