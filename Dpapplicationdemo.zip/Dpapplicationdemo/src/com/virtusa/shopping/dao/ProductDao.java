package com.virtusa.shopping.dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.shopping.models.Product;

public interface ProductDao {
int addProduct(Product product) throws SQLException;
List<Object[]> getproducts() throws SQLException;
Product getproductById(int prodId);
int countproducts(String catName) throws SQLException;
}
