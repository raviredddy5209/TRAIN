 package com.virtusa.shopping.views;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import com.virtusa.shopping.dao.CategoryDao;
import com.virtusa.shopping.dao.CategoryImpl;
import com.virtusa.shopping.models.Category;
public class CategoryView {
    private static Scanner scanner=new Scanner(System.in);
    private static CategoryDao dao=new CategoryImpl();
    private static List<Category> categoryList=new ArrayList<Category>();
    public static void getCategories()
    {
        try {
            for(Category category:dao.getCategories())
            {
                System.out.println(category.getCatId()+"\t"+category.getCatName()+"\n");
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }    
        //get category by id
        public static void getCategoryById()
        {
            System.out.println("Ente Category Id");
            Category category = null;
            try {
                category = dao.getCateggoryById(scanner.nextInt());
                System.out.println(category.getCatId()+"\t"+category.getCatName());
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        //insert batch statements
        public static void addAllCategories()
        {
            //create categories
                Category category;
                for(int i=0;i<100;i++)
                {
                    category=new Category();
                    category.setCatId(new Random().nextInt(1000000));
                    category.setCatName("category"+i);
                    categoryList.add(category);
                }
                try
                {
                    int[] records=dao.addAllCategory(categoryList);
                    System.out.println(records);
                }
                catch(SQLException e)
                {
                    e.printStackTrace();
                }
            
        }
    }













/**
public class CategoryView {

  private static Scanner scanner=new Scanner(System.in);;
  private static CategoryDao dao=new CategoryImpl();
    
//    public CategoryView() {
//       private static Scanner scanner=new Scanner(System.in);
//      private static CategoryDao  dao=new CategoryImpl();
//    }
    public void getCategories() {

 

        CategoryDao dao=new CategoryImpl();
        try {
            for(Category category: dao.getCategories()) {
                System.out.println(category.getCatId()+"\t"+category.getCatName());
            }
        }catch(SQLException se) {
            se.printStackTrace();
        }
        
    }
    
    
    public static void getCategoryById() throws SQLException {
        System.out.println("Enter Category Id:");
        Category category =dao.getCategoryById(scanner.nextInt());
        System.out.println(category.getCatId()+"\t"+category.getCatName());
    }
    public  static void addAllCategories()
    {
    	//create categories
    	Category category;
    	for(int i=0;i<100;i++)
    	{
    		category = new Category();
    		category.getCatId(new Random().nextInt(1000000));
    		category.setCatName("category-" + i);
    		categoryList.add(category);
    	}
    	//bulk insert
    	try {
    		int[] records = dao.addAllCategory(categoryList);
    		System.out.println(records);
    	}catch(SQLException e)
    	{
    		e.printStackTrace();
    	}    
   */