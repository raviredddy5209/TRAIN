package com.virtusa.shopping.views;

import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.shopping.dao.CategoryDao;
import com.virtusa.shopping.dao.CategoryImpl;
import com.virtusa.shopping.dao.ProductDao;
import com.virtusa.shopping.dao.ProductImpl;
import com.virtusa.shopping.models.Product;

public class ProductView {
private static Scanner   scanner= new Scanner(System.in);
private static CategoryDao catDao = new CategoryImpl();
private static ProductDao dao = new ProductImpl();
private static Product product;
private static Logger logger = Logger.getLogger(ProductView.class);
static {
	PropertyConfigurator.configure("log4j.properties");
}






 public static void addProduct()
 {
	 product = new Product();
	 System.out.println("Enter Product Id");
	 product.setProdId(scanner.nextInt());
	 scanner.nextLine();
	 System.out.println("Enter Product Name");
	 product.setProdName(scanner.nextLine());
	 System.out.println("Enter product dop(dd-MM-yyyy)");
	 SimpleDateFormat  sdf = new SimpleDateFormat("dd-MM-yyyy");
	 String date= scanner.nextLine();
	 Date dop = null;
	 java.util.Date result =null;
	 try {
		 result = sdf.parse(date);
		 dop= new Date(result.getYear(),result.getMonth(),result.getDay());
		 product.setDop(dop);
		 System.out.println("ENter Product Cost");
		 product.setCost(scanner.nextInt());
		 scanner.nextLine();
		 System.out.println("Enter category id");
		 product.setCategory(catDao.getCateggoryById(scanner.nextInt()));
		 int count = dao.addProduct(product);
		 if(count>0)
			 System.out.println("Recorded Added");
	 }catch (SQLException e) {
		// TODO: handle exception
		 e.printStackTrace();
	}catch (ParseException e) {
		// TODO: handle exception
		System.out.println(e.getMessage());
	}
	 
	 
 }
 public static void getAllproducts() {
	 try {
		 for(Object[] objects  : dao.getproducts())
			 {for(Object obj : objects)
				 System.out.println(obj+"\t");
			 System.out.println("\n");
			 }
	 }catch (SQLException e) {
		// TODO: handle exception
		 e.printStackTrace();
	}
 }
 public static void  getCount()
 {
	 logger.info("Product count starts by Category Name");
	 System.out.println("Enter category name");
	 try {
	// System.out.println("Count =  " + dao.countproducts(scanner.nextLine()));
		 logger.info("Count =  " + dao.countproducts(scanner.nextLine()));
	 }catch (SQLException e) {
		// TODO: handle exception
		// e.printStackTrace();
		 logger.error("Sql exception" + e.getMessage());
	}
 }
}
