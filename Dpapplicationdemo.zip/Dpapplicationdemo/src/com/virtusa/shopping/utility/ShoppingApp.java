package com.virtusa.shopping.utility;

import java.sql.Connection;
import java.sql.SQLException;

import com.virtusa.shopping.dao.CategoryDao;
import com.virtusa.shopping.dao.CategoryImpl;
import com.virtusa.shopping.helpers.MySqlHelper;
import com.virtusa.shopping.models.Category;
import com.virtusa.shopping.views.CategoryView;
import com.virtusa.shopping.views.ProductView;

public class ShoppingApp {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
//		Connection conn = MySqlHelper.getConnection();
//		if(conn!=null)
//			System.out.println("MYSQL connection created!!");
//		else
//			
//			System.out.println(" MYSQL connection failed!!");
	
		
		/**
		
		CategoryDao dao = new CategoryImpl();
		try {
			for(Category category : dao.getCategories())
			{
				System.out.println(category.getCatId()+"\t" + category.getCatName());
			}
		}catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}*/
		
		//CategoryView.getCategoryById();
		//CategoryView.addAllCategories();
		//ProductView.addProduct();
		//ProductView.getAllproducts();
		ProductView.getCount();
		 
		}
	}

