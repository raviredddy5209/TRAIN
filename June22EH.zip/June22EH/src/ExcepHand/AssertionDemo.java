package ExcepHand;

import java.util.Scanner;

public class AssertionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner  = new Scanner(System.in);
		System.out.println("Enter card no");
		//long debno = scanner.nextLong();
		//tring b = Long.toString(debno);
		//assert(b.length()==12) : "Valid" ;
		long debno = scanner.nextLong();
		int length=String.valueOf(debno).length();
		try {
			assert(length==12) : "card no should be in 12 digits";
			
		}
		catch(AssertionError error) {
			System.out.println(error.getMessage());
		}
		finally {
			scanner.close();
		}
	}

}