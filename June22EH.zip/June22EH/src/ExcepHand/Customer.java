package ExcepHand;
import java.time.LocalDate;
import java.util.regex.Pattern;

import com.virtusa.exceptions.NegativeNoExceptions;

public class Customer {
	 	private int cusId;
		private String cusName;
		private LocalDate dob;
		private String address;
		
		public int getCusId() {
			return cusId;
		}
		public void setCusId(int cusId) {
			//this.cusId = cusId;
			if(cusId<0)
				throw new NegativeNoExceptions("customer id cant be negative");
			else
				this.cusId = cusId;
				
		}
		public String getCusName() {
			return cusName;
		}
		public void setCusName(String cusName) {
			if(Pattern.matches("[A-Za-z]*", cusName))
			this.cusName = cusName;
			else
				throw new NegativeNoExceptions("Name should only be in alphabets");
		}
		public LocalDate getDob() {
			return dob;
		}
		public void setDob(LocalDate dob) {
			this.dob = dob;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		
	}

