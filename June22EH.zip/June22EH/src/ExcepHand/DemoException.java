package ExcepHand;

import java.util.Scanner;

public class DemoException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final int c;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the a value");
		 int a=scanner.nextInt();
		 System.out.println("Enter the bvalue");
		 int b=scanner.nextInt();
		 System.out.println("Enter any String");
		 String s=scanner.nextLine();
		 try
		 {
			   c = a/b;
			  // System.out.println(s.length());
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace( );
		 }
		 
		 
		 try
		 {
			  // c = a/b;
			   System.out.println(s.length());
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace( );
		 }
		 
		 

	}

}
