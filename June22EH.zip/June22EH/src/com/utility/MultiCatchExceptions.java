package com.utility;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

import com.virtusa.exceptions.NegativeNoExceptions;

import ExcepHand.Customer;

public class MultiCatchExceptions {
public static Date convertStringToDate(String dob) throws ParseException{
	SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
	return formatter.parse(dob);
}
			@SuppressWarnings("deprecation")
			public static void main(String[] args)   {
				// TODO Auto-generated method stub
		         
				//Customer[] customers=new Customer[3];
				Scanner scanner  = new Scanner(System.in);
				String id = null;
				String dob = null;
				Date date = null;
				try {
					Customer[] customers=new Customer[3];
					for(int i=0;i<=3;i++)
					{
						customers[i]=new Customer();
						System.out.println("enter customer id");
						id = scanner.nextLine();
						//customers[i].setCusId(scanner.nextInt());
						customers[i].setCusId(Integer.parseInt(id));
						//scanner.nextLine();
						System.out.println("enter customer Name");
						customers[i].setCusName(scanner.nextLine());
						System.out.println("Enter the date of joining");
						  dob=scanner.nextLine();
						SimpleDateFormat formatter=new SimpleDateFormat("dd-MM-yyyy");
						date = formatter.parse(dob);
						customers[i].setDob(LocalDate.of(date.getYear(),date.getMonth(),date.getDay()));
						
					}
				}
				catch(ParseException  e)
				{
					System.out.println("wrong date format");
				}
				catch(NegativeNoExceptions  neg)
				{
					System.out.println(neg.getMessage());
				}
				catch(ArrayIndexOutOfBoundsException ar)
				{
					System.out.println(ar.getMessage());
					StackTraceElement[] elements = ar.getStackTrace();
					for(StackTraceElement element:elements)
					{
						System.out.println(element.getFileName());
						System.out.println(element.getClassName());
						System.out.println(element.getLineNumber());
						System.out.println(element.getMethodName());
						System.out.println(element.getClass());
					
					}
				}
				
			}

		

}
