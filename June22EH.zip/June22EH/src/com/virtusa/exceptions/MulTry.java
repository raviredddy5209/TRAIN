package com.virtusa.exceptions;

public class MulTry {

	public static void main(String[] s) {
		// TODO Auto-generated method stub
		try {
			try {
				String n[]  = new String[s.length-1];
				System.out.println(n[0]);
			} 
			catch(ArrayIndexOutOfBoundsException ae) {
				System.out.println("out of bounds");	
			}
		}
		catch(NegativeArraySizeException ne)
		{
			System.out.println("Array size cannot be negative");
		}

	}

}
