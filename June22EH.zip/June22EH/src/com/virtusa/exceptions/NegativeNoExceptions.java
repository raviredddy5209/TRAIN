package com.virtusa.exceptions;

public class NegativeNoExceptions  extends RuntimeException{
  String message;
  public NegativeNoExceptions(String message)
  {
	  super(message);
	  this.message = message;
  }
 
}
