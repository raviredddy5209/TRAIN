package com.virtusa.banking.threaddemo;

import com.virtusa.banking.model.ProducerConsumer;

public class InterThreadCommDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProducerConsumer pc = new ProducerConsumer();
		Thread t1 = new Thread(pc,"Producer");
		Thread t2 = new Thread(pc,"Consumer");
		Thread t3 = new Thread(pc,"Consumer");
		Thread t4 = new Thread(pc,"Consumer");
		t1.start();
		t1.start();
		t2.start();


	}

}
