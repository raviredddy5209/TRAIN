package com.virtusa.banking.threaddemo;

public class SyncSnippet extends Thread {
	

	public SyncSnippet(String name) {
		// TODO Auto-generated constructor stub
		this.setName(name);
	} 

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//super.run();
		synchronized (this) {
			
		}
		for(int i=0;i<10;i++)
		{
			System.out.println(Thread.currentThread().getName() +"\t" + i);
		}
	}


	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
SyncSnippet[] snippet  = new SyncSnippet[2];
for(int i=0;i<2;i++)
{
	snippet[i] = new SyncSnippet("Snippet" + i);
	snippet[i].start();
	snippet[i].join();
	//snippet[i].yield();
	
}
	}

}
