package com.virtusa.banking.threaddemo;
import com.virtusa.banking.model.Vehicle;
public class SynchronizationDemo implements Runnable {
	
	private Vehicle vehicle;
	
	public SynchronizationDemo(Vehicle vehicle,String name)
	{
		this.vehicle = vehicle;
		new Thread(this,name).start();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicle vehicles = new Vehicle();
		SynchronizationDemo[] synchronizationDemo = new SynchronizationDemo[5];
		for(int i=0;i<synchronizationDemo.length;i++)
		{
			synchronizationDemo[i]  = new  SynchronizationDemo( vehicles, "Vehicle-" + i );
			//vehicles[i]=new Vehicle("Vechile-"+i);
			//vehicles[i].start();
		//	try {
			//	vehicles[i].join();
			//}catch(InterruptedException e)
			//{
			//	e.printStackTrace();
			//}
		}
	}





	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized (vehicle) {
			vehicle.vehiclemessage();
			
		}
		
	}

}