package com.virtusa.banking.model;

//import com.virtusa.banking.model.Vehicle;

public class Account {
	private int money;
	public  Account(int amt)
	{
		//get amt from database
		money=amt;
	}
		public void withdraw(int amt) {
			if(amt<money) {
				try {
					Thread.sleep(1000);
					money = money-amt;
				}catch (Exception e) {
					// TODO: handle exception
					System.out.println("Received amt" + amt + "by" + Thread.currentThread().getName());
					
				}
			}
			else
				System.out.println("Sorry" + Thread.currentThread().getName() + "requested amount" + amt + " is not available");
			System.out.println("Balance " + money);	
				
		}
	}
