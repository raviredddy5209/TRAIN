package com.virtusa.banking.model;

public class ThreadGroupDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ThreadGroup tg = new ThreadGroup("group 1");
Thread t1 = new Thread(tg,"thread 1");
Thread t2 = new Thread(tg,"thread 2");
Thread t3 = new Thread(tg,"thread 3");
tg = new ThreadGroup("group 2");
Thread t4 = new Thread(tg,"thread 4");
tg = Thread.currentThread().getThreadGroup();
int agc = tg.activeGroupCount();
System.out.println("Active thread groups in  " + tg.getName() + "  thread group" + agc);
	}

}
