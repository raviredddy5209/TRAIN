package com.virtusa.banking.model;

public class ToolBooth  extends Thread{
	 public void tollMessage() throws InterruptedException
	 {
		 System.out.println("Crossing the the Tollgate");
		 Thread.sleep(2000);
	 }
	 
}
 