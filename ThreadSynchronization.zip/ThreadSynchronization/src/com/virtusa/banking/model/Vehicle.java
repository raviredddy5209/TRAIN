package com.virtusa.banking.model;

public class Vehicle     {
	public void vehiclemessage() {
		System.out.println(Thread.currentThread().getName()+ "\t");
		try
		{
			new Bridge().bridgeMessage();
			new ToolBooth().tollMessage();
			System.out.println("\n");
			
		}catch (InterruptedException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		}
	
	
/*	private Bridge bridge;
	private ToolBooth toll;
	public Vehicle(String name) {
		this.setName(name);
		bridge  = new Bridge();
		toll = new ToolBooth();
		}

	@Override
	public synchronized  void run() {
		// TODO Auto-generated method stub

		//super.run();
	 
	
*/
}
