package com.virtusa.banking.model;

import java.util.ArrayList;
import java.util.List;

public class ProducerConsumer implements Runnable {

	private List<String> messages;
	public ProducerConsumer()
	{
		messages=new ArrayList<String>();
	}
	public synchronized void write() throws InterruptedException
	{
		while(true)
		{
		//if(message==null)
        if(messages.size()==0)
			{
			System.out.println("Creating bulk of 100 memes!!!");
			
	//	message="Ready with meme";
     //   message=new ArrayList〈String〉();
        for(int i=0;i<50;i++)
        	messages.add("meme-"+i);
		Thread.sleep(2000);
		notify();
			}		
		else
			wait();
	}
	}
	public synchronized void read() throws InterruptedException
	{
		while(true)
		{
		//	if(message==null)
			if(messages.size()==0)
			     wait();
			else
			{
			    for(String msg : messages)	
			    {
				System.out.println("Reading message"+messages);
				Thread.sleep(1000);
			    }
			    messages.clear();
			    notify();
			}
		}
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try {
		if(Thread.currentThread().getName().equals("Producer"))
		   write();
		   else
			   read();
	}
		catch(InterruptedException ex)
		{
			ex.printStackTrace();
		}

}
}