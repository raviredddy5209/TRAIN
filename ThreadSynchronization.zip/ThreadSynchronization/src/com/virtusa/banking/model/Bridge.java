package com.virtusa.banking.model;

public class Bridge {
public synchronized void bridgeMessage()
{
	System.out.println("Crossing the  Bridge");
	try {
		Thread.sleep(2000);
	}catch (InterruptedException e) {
		// TODO: handle exception
		e.printStackTrace();
	}
}
}
