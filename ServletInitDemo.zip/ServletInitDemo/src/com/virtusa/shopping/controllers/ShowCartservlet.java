package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.shopping.models.ItemQty;

/**
 * Servlet implementation class ShowCartservlet
 */
@WebServlet("/ShowCartservlet")
public class ShowCartservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowCartservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	/**protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//read from session
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		List<String> items=null;
		int i=1;
		if(!session.isNew())//old session
		{
			if(session.getAttribute("cart")!=null)
			{
				out.print("<h4> Happy  shopping</h4>");
				out.println("<h4>Items available on Cart</h4>");
				//items=(List<String>) session.getAttribute("cart");
			
			items=(List<String>) session.getAttribute("cart");
			System.out.println("output ");
			for(String item : items)
			{
				//out.println("<p style='margin-left:40%;color:red;>"+i+"."+item.toUpperCase()+"</p>");
				//i++;
				out.println(item+"<br/>");
			}
			//out.println("<p style='margin-left:40%;color:red;'href='category.html>'+i+"."");
			out.println("<a href='category.html'>Go back to shopping</a>");
		}}
	}

}**/
	 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        PrintWriter out=response.getWriter();

 

        response.setContentType("text/html");

 

        HttpSession session=request.getSession();

 

        List<ItemQty> items=null;

 

        int i=1;

 

        if(!session.isNew())//old session

 

        {

 

          if(session.getAttribute("cart")!=null)

 

          {

 

            out.println("<h4 style='text-align:center'>Happy Shopping</h4>");

 

            out.println("<h4 style='text-align:center'>Items Available on Cart</h4>");

 

            items=(List<ItemQty>) session.getAttribute("cart");

 

            

 

            for(ItemQty item : items)

 

            {

 

                out.println("<p style='margin-left:40%;color:red;'>"+i+"."+item.getName().toUpperCase()

 

                        +"&nbsp;"+item.getQty()+"&nbsp;"+item.getAmount()+"</p>");

 

                i++;

 

            }

 

            

 

            out.println("<a style='margin-left:40%; color:blue;' href='category.html'>Go Back to Shopping</a>");

 

          }

 

            

 

        }
    }

 

}
 
