package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DBServlet
 */
@WebServlet(
		urlPatterns = { "/DBServlet" }, 
		initParams = { 
				@WebInitParam(name = "url", value = "http://localhost:3306"), 
				@WebInitParam(name = "driver", value = "com.jdbc.mysql.Driver")
		})
public class DBServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private String url,driver;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DBServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		out.println("<p>URL="+this.url+"</p><br/>");
		out.println("<p> DRIVER="+this.driver+"</p><br/>");
		
	}

	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
	}

	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		this.url=config.getInitParameter("url");
		this.driver=config.getInitParameter("driver");
	//	super.init(config);
	}

}
