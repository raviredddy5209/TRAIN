package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.shopping.dao.ItemDao;
import com.virtusa.shopping.dao.ItemImpl;
import com.virtusa.shopping.models.Item;
import com.virtusa.shopping.models.ItemQty;

/**
 * Servlet implementation class cartServlet
 */
@WebServlet(name = "CartServlet", urlPatterns = { "/CartServlet" })
public class cartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// TODO Auto-generated method stub

		PrintWriter out=response.getWriter();

		response.setContentType("text/html");

		String[] books=request.getParameterValues("books");

		String[] music=request.getParameterValues("music");

		//session

		HttpSession session =request.getSession();

		List<ItemQty> items=new ArrayList<ItemQty>();

		ItemDao dao=new ItemImpl();

		

		int qty;

		long price;

		ItemQty itemQty=null;

		if(books!=null)

		{

			System.out.println("Books Available...");

			qty=0;

			price=0;

			for(String book : books)

			{

				//items.add(book);

			     qty= Integer.parseInt(request.getParameter(book+"Qty"));	

                 for(Item item:dao.getItemList())

                 {

                	 if(book.equals(item.getName()))

                	 {

                		 price=item.getPrice();

                		 itemQty=new ItemQty();

                		 itemQty.setName(book);

                		 itemQty.setQty(qty);

                		 itemQty.setAmount(qty*price);

                		 items.add(itemQty);

                	 }

                 }

			     

			     

			}

		}

		if(music!=null)

		{

			System.out.println("Music Available...");

			//items.add(book);

			for(String name : music)

			{

				//items.add(book);

			     qty= Integer.parseInt(request.getParameter(name+"Qty"));	

                 for(Item item:dao.getItemList())

                 {

                	 if(name.equals(item.getName()))

                	 {

                		 price=item.getPrice();

                		 itemQty=new ItemQty();

                		 itemQty.setName(name);

                		 itemQty.setQty(qty);

                		 itemQty.setAmount(qty*price);

                		 items.add(itemQty);

                	 }

                 }
 
			}

		     

		}

		

		List<ItemQty> cartItems=null;

		

		if(session.getAttribute("cart")==null)

		{

			System.out.println("Adding to Cart...");

			session.setAttribute("cart", items);

			request.getRequestDispatcher("category.html").forward(request, response);

		}

		else

		{

			System.out.println("retrieving from Cart...");

			 cartItems=(List<ItemQty>) session.getAttribute("cart");	

			 cartItems.addAll(items);

			 session.setAttribute("cart", cartItems);

			 

			request.getRequestDispatcher("category.html").forward(request, response);

			

			

		}

		

		

		

		

		

	}



}