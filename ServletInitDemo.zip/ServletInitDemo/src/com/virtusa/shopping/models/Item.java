package com.virtusa.shopping.models;

public class Item {
private	int Id;
	private String name;
	private long price;
	public Item(int Id, String name, int price) {
		// TODO Auto-generated constructor stub
		this.Id=Id;
		this.name=name;
		this.price=price;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	

}
