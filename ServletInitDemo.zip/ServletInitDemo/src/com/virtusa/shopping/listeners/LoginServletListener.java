package com.virtusa.shopping.listeners;

import java.time.LocalDateTime;

import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class LoginServletListener
 *
 */
@WebListener
public class LoginServletListener implements ServletRequestListener, ServletRequestAttributeListener {
//  DateTime starttime,finishtime;
	 private LocalDateTime starttime, finishtime;
    /**
     * Default constructor. 
     */
    public LoginServletListener() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletRequestListener#requestDestroyed(ServletRequestEvent)
     */
    public void requestDestroyed(ServletRequestEvent arg0)  { 
         // TODO Auto-generated method stub
    	   System.out.println("Login Request destroyed:="+LocalDateTime.now());
           finishtime=LocalDateTime.now();
           System.out.println(finishtime.getNano()-starttime.getNano());
    }

	/**
     * @see ServletRequestAttributeListener#attributeRemoved(ServletRequestAttributeEvent)
     */
    public void attributeRemoved(ServletRequestAttributeEvent arg0)  { 
         // TODO Auto-generated method stub
    }

	/**
     * @see ServletRequestListener#requestInitialized(ServletRequestEvent)
     */
    public void requestInitialized(ServletRequestEvent arg0)  { 
         // TODO Auto-generated method stub
    	  System.out.println("Login Request Initialized:="+LocalDateTime.now());
          starttime=LocalDateTime.now();
    }

	/**
     * @see ServletRequestAttributeListener#attributeAdded(ServletRequestAttributeEvent)
     */
    public void attributeAdded(ServletRequestAttributeEvent arg0)  { 
         // TODO Auto-generated method stub
    }

	/**
     * @see ServletRequestAttributeListener#attributeReplaced(ServletRequestAttributeEvent)
     */
    public void attributeReplaced(ServletRequestAttributeEvent arg0)  { 
         // TODO Auto-generated method stub
    	
    }
	
}
