package com.virtusa.shopping.security;

package com.virtusa.shopping.security;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Key;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;


public class EncryptDecrypt {

	private static final String ALGO = "DES";
	private static final String MODE = "ECB";
	private static final String PADDING = "PKCS5Padding";
	private static int mode = 0;

	

	public static void encrypt(String pwd) {
	try {
	    System.out.println("Start encryption ...");

	    /* Get Input Data */
	    String input = pwd;
	    System.out.println("Input data : "+input);

	    /* Create Secret Key */
	    KeyGenerator keyGen = KeyGenerator.getInstance(ALGO);
	    SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");
	    keyGen.init(56,random);
	      Key sharedKey = keyGen.generateKey();

	    /* Create the Cipher and init it with the secret key */
	    Cipher c = Cipher.getInstance(ALGO+"/"+MODE+"/"+PADDING);
	    //System.out.println("\n" + c.getProvider().getInfo());
	    c.init(Cipher.ENCRYPT_MODE,sharedKey);
	    byte[] ciphertext = c.doFinal(input.getBytes());
	    System.out.println("Input Encrypted : "+new String(ciphertext,"UTF8"));

	    /* Save key to a file */
	    save(sharedKey.getEncoded(),"shared.key");

	    /* Save encrypted data to a file */
	    save(ciphertext,"encrypted.txt");
	} catch (Exception e) {
	    e.printStackTrace();
	}   
	}

	public static String decrypt() {
		String pwd=null;
	try {
	    System.out.println("Start decryption ...");

	    /* Get encoded shared key from file*/
	    byte[] encoded = load("shared.key");
	      SecretKeyFactory kf = SecretKeyFactory.getInstance(ALGO);
	    KeySpec ks = new DESKeySpec(encoded);
	    SecretKey ky = kf.generateSecret(ks);

	    /* Get encoded data */
	    byte[] ciphertext = load("encrypted.txt");
	    System.out.println("Encoded data = " + new String(ciphertext,"UTF8"));

	    /* Create a Cipher object and initialize it with the secret key */
	    Cipher c = Cipher.getInstance(ALGO+"/"+MODE+"/"+PADDING);
	    c.init(Cipher.DECRYPT_MODE,ky);

	    /* Update and decrypt */
	    byte[] plainText = c.doFinal(ciphertext);
	    pwd=new String(plainText,"UTF8");
	} catch (Exception e) {
	    e.printStackTrace();
	}   
	return pwd;
	}
	
	private static void save(byte[] buf, String file) throws IOException {
	      FileOutputStream fos = new FileOutputStream(file);
	      fos.write(buf);
	      fos.close();
	}

	private static byte[] load(String file) throws FileNotFoundException, IOException {
	    FileInputStream fis = new FileInputStream(file);
	    byte[] buf = new byte[fis.available()];
	    fis.read(buf);
	    fis.close();
	    return buf;
	}


    

}