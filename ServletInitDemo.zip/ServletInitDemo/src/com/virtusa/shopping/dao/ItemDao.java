package com.virtusa.shopping.dao;

import java.util.List;

import com.virtusa.shopping.models.Item;

public interface ItemDao  {
    public List<Item> getItemList();



}