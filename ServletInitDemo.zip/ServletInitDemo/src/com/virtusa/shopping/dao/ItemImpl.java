package com.virtusa.shopping.dao;

import java.util.ArrayList;
import java.util.List;

import com.virtusa.shopping.models.Item;

public class ItemImpl implements ItemDao{

	@Override
	public List<Item> getItemList() {
		// TODO Auto-generated method stub
		
		List<Item> productList = new ArrayList<Item>();
		Item item = new Item(1,"Java",345);
		productList.add(item);
		item = new Item(2,"C",345);
		productList.add(item);
		item = new Item(3,"C++",445);
		productList.add(item);
		item = new Item(4,"JS",545);
		productList.add(item);
		item = new Item(5,"m1",645);
		productList.add(item);
		item = new Item(6,"m5",745);
		productList.add(item);
		
		return productList;
	}

}