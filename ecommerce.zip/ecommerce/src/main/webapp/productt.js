window.addEventListener('load',function()

{ 
	var fname = document.getElementById('firstName');

    fname.oninvalid = function(event) {

        if(fname.value === '')

            event.target.setCustomValidity('cannot be empty');

        else if(fname.validity.patternMismatch)

           event.target.setCustomValidity('First Name should only contain letters. e.g. Ajay');

        else

            event.target.setCustomValidity('');

        return true;

    }
 var lname = document.getElementById('lastName');

    lname.oninvalid = function(event) {

        if(fname.value === '')

            event.target.setCustomValidity('cannot be empty');

        else if(fname.validity.patternMismatch)

            event.target.setCustomValidity('Last Name should only contain letters. e.g. Ajay');

        else

            event.target.setCustomValidity('');

        return true;

    }

    

    var form = document.getElementById("contact");

    

    form.addEventListener('submit',function()

    		{

    	           //alert("form submitted");

    	var xhr=null;

    	         //create ajax object

    	          

    	          try

    	          {

    	        	  xhr= new XMLHttpRequest(); //chrome,safari,firefox

    	        	  

    	          }

    	          catch(err)

    	          {

    	        	  try

    	        	  {

    	        		  xhr = new ActiveXObject("MSXML2.XMLHttp.6.0"); //IE

    	        	  }

    	        	  catch(err)

    	        	  {

    	        		  console.log("Ajax Object not created");

    	        	  }
 
    	          }

    	          

    	          //Ajax Event handling 

    	          //once response received from server

    	          xhr.onreadystatechange = function()

    	          {

    	        	  alert("Entering...");

    	        	  var response=null;

    	        	  if (xhr.readyState == 4)//successful response

    	        		  {

    	        		   response=xhr.responseText;

    	        		   alert(response);

    	        		  }

    	        	 

    	          }

    	          //open the connection

    	          xhr.open('post','ContactServlet',false);

    	          xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    	          //read values from form

    	          var firstName=document.getElementById('firstName').value;

    	          var lastName=document.getElementById('lastName').value;

    	          var dob=document.getElementById('dob').value;

    	          var email=document.getElementById('email').value;

    	          var address=document.getElementById('address').value;

    	          var mobileNo=document.getElementById('mobileNo').value;    	             	          

    	          xhr.send("firstName="+firstName+"&lastName="+lastName+

    	        		  "&dob="+dob+"&email="+email+"&address="+address+"&mobileNo="+mobileNo);
          return false;

    	

    		});
 
return false;

}



)

