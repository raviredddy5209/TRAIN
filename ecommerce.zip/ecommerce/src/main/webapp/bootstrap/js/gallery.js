window.addEventListener('load', function()
{
    canvas=document.getElementById('olympic');
    context=canvas.getContext('2d');
    contextX=canvas.width/2;
    contextY=canvas.height/2;
    radius=30;
    x=-50;
    y=-20;
    var array=new Array('blue','green','yellow')
    for(i=0;i<3;i++)
        {
    context.beginPath();  
    context.arc(contextX+x,contextY+y,radius,0,2*Math.PI,false);
    context.lineWidth=3;
    context.strokeStyle=array[i];
    context.stroke();
    x=x+30;
    context.closePath();
        }
    var array=new Array('orange','red')
    x=-30;
    y=0;
    for(i=0;i<2;i++)
        {
    context.beginPath();  
    context.arc(contextX+x,contextY+y,radius,0,2*Math.PI,false);
    context.lineWidth=3;
    context.strokeStyle=array[i];
    context.stroke();
    x=x+30;
    context.closePath();
        }
})