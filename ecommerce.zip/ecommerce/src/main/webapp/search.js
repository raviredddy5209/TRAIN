window.addEventListener('load',function()

		{
 
	   var form=document.getElementById("searchFrm");
 
	   form.addEventListener('submit',function()

	    		{ 
	    	          //alert("form submitted");

	    	var xhr=null;

	    	         //create ajax object

	    	          

	    	          try

	    	          {

	    	        	  xhr= new XMLHttpRequest(); //chrome,safari,firefox
 

	    	          }

	    	          catch(err)

	    	          {

	    	        	  try

	    	        	  {

	    	        		  xhr = new ActiveXObject("MSXML2.XMLHttp.6.0"); //IE

	    	        	  }

	    	        	  catch(err)

	    	        	  {

	    	        		  console.log("Ajax Object not created");

	    	        	  }

	    	        	   
	    	          }

	    	          

	    	          //Ajax Event handling 

	    	          //once response received from server
 
	    	          xhr.onreadystatechange = function()

	    	          {

	    	         
	    	        	  var response=null;

	    	        	  var result=document.getElementById("result");

	    	        	  if (xhr.readyState == 4)//successful response

	    	        		  

                          {
 
                           response=xhr.responseText;

                           //alert(response);
 
                           response=JSON.parse(response);
                           
//                           result.innerHTML="<table class='search'><tr><th>MobileNo</th>" +
//                           		"<th>First Name</th>"+
//                           "<th>Last Name</th><th>DOB</th><th>Email</th><th>Address</th>
//                           </tr><tr>"
                           result.innerHTML="<table class='search'><tr><th>MobileNo</th><th>" +
                           		" FirstName</th>"+"<th>last Name</th><th>DOB</th><th>Address</th><th>Email</th></tr><tr>"
                           for(var data in response)
                           {
                               
                               result.innerHTML=result.innerHTML+"<td>"+response[data]+"</td>";
                           }
                          result.innerHTML=result.innerHTML+"</tr></table>"
                           
                          }
 

	    	          }

	    	          //open the connection

	    	          xhr.open('post','SearchServlet',false);

	    	          xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

	    	          //read values from form	    	          

	    	          var mobileNo=document.getElementById('mobileNo').value;    	             	          

	    	          xhr.send("mobileNo="+mobileNo);
       return false;
  
	    		});
 
	return false;
 
		})