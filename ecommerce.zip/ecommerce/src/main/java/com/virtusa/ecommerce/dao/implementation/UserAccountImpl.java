package com.virtusa.ecommerce.dao.implementation;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

 
import com.virtusa.ecommerce.dao.interfaces.UserAccountDao;
import com.virtusa.ecommerce.helpers.MySqlHelper;
import com.virtusa.ecommerce.models.UserAccount;

public class UserAccountImpl  implements UserAccountDao{

	 private Connection conn;
	 private CallableStatement callable;
	 private PreparedStatement preparedstatement;
	 
	@Override
	public boolean addUserAccount(UserAccount userAccount) throws SQLException {
		// TODO Auto-generated method stub
		conn = MySqlHelper.getConnection();
		int count = 0;
		boolean status = false;
		try {
			callable =  conn.prepareCall("{call addUser(?,?,?,?,?,?)}");
			callable.setLong(1, userAccount.getMobileNo());
			callable.setString(2, userAccount.getFirstName());
			callable.setString(3,userAccount.getLastName());
			callable.setDate(4, userAccount.getDob());
			callable.setString(5,userAccount.getEmail());
			callable.setString(6,userAccount.getAddress());
			count = callable.executeUpdate();
			if(count>0)
				status=true;
		}catch (SQLException e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		
		return status;
	}

	@Override
	public UserAccount getUserById(long mobileNo) throws SQLException {
        // TODO Auto-generated method stub
        conn=MySqlHelper.getConnection();
        ResourceBundle bundle=ResourceBundle.getBundle("com/virtusa/ecommerce/resource/db");
        String query=bundle.getString("searchQuery");
        preparedstatement=conn.prepareStatement(query);
        preparedstatement.setLong(1, mobileNo);
        ResultSet rs=preparedstatement.executeQuery();
        rs.next();
        UserAccount userAccount=new UserAccount();
        userAccount.setMobileNo(rs.getLong(1));
        userAccount.setFirstName(rs.getString(2));
        userAccount.setLastName(rs.getString(3));
        userAccount.setDob(rs.getDate(4));
        userAccount.setAddress(rs.getString(5));
        userAccount.setEmail(rs.getString(6));
        conn.close();
        return userAccount;
    }
	 
}
