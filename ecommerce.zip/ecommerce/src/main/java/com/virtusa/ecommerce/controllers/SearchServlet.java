package com.virtusa.ecommerce.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.virtusa.ecommerce.dao.implementation.UserAccountImpl;
import com.virtusa.ecommerce.dao.interfaces.UserAccountDao;
import com.virtusa.ecommerce.models.UserAccount;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		 Long mobileNo=Long.parseLong(request.getParameter("mobileNo"));
		 response.setContentType("application/json");
		 UserAccountDao dao = new UserAccountImpl();
		 UserAccount userAccount=null;
		 try {
			 userAccount=dao.getUserById(mobileNo);
		 }catch (SQLException e) {
			 e.printStackTrace();
			// TODO: handle exception
		}
		 out.println(new Gson().toJson(userAccount));
	}

}
