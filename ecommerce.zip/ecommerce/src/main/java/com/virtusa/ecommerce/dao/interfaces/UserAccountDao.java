package com.virtusa.ecommerce.dao.interfaces;

import java.sql.SQLException;

import com.virtusa.ecommerce.models.UserAccount;

public interface UserAccountDao {
boolean addUserAccount(UserAccount userAccount) throws SQLException;
 UserAccount getUserById(long mobileNo) throws SQLException;
}
