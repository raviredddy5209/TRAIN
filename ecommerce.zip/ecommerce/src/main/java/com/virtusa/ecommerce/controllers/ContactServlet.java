package com.virtusa.ecommerce.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.ecommerce.dao.implementation.UserAccountImpl;
import com.virtusa.ecommerce.dao.interfaces.UserAccountDao;
import com.virtusa.ecommerce.models.UserAccount;

/**
 * Servlet implementation class ContactServlet
 */
public class ContactServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ContactServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);\
//		PrintWriter out = response.getWriter();
//		
//		String firstName=request.getParameter("firstName");
//		out.println("Received first name " + firstName);
		PrintWriter out = response.getWriter();
		 Enumeration<String> enumeration = request.getParameterNames();
	//	 response.setContentType("text/html");
		String name=null;
		UserAccount userAccount = new UserAccount();
		Hashtable<String,String> ht =new Hashtable<String,String>();
		 //dao layer calls procedure and sets the value
		 while(enumeration.hasMoreElements())
		 {
			name = enumeration.nextElement();
			out.println(name +":" + request.getParameter(name)+"<br/>");
			ht.put(name, request.getParameter(name));
			 
			 
	}
		userAccount.setFirstName(ht.get("firstName"));
		userAccount.setLastName(ht.get("lastName"));
		userAccount.setAddress(ht.get("address"));
		userAccount.setEmail(ht.get("email"));
		userAccount.setMobileNo( Long.parseLong(ht.get("mobileNo")));
	    SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
	    try
	    {
	    	Date dob = ft.parse(ht.get("dob"));
	    	userAccount.setDob(new java.sql.Date(dob.getYear(),dob.getMonth(),dob.getDay()));
	    }catch (ParseException e) {
			// TODO: handle exception
	    	e.printStackTrace();
		}
	    
	    UserAccountDao uai=new UserAccountImpl();
	         boolean status=false;
	         try {
	             status=uai.addUserAccount(userAccount);
	         } catch (SQLException e) {
	             // TODO Auto-generated catch block
	             e.printStackTrace();
	         }
	         
	         if(status)
	             System.out.println("Record added successfully");
	         else
	            System.out.println("record  not added  ");
	         
	          
		
	}

}
