package com.virtusa.ecommerce.helpers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class MySqlHelper {
	private static Connection conn;
	static Logger logger=Logger.getLogger(MySqlHelper.class);
	static {
		PropertyConfigurator.configure("log4j.properties");
	}
public static Connection getConnection() {
	ResourceBundle rb = ResourceBundle.getBundle("com/virtusa/ecommerce/resource/db");
	String userName = rb.getString("user");
	String password = rb.getString("password");
	String url =rb.getString("url");
	String driverName = rb.getString("driver");
	try {
		Class.forName(driverName);
		conn=DriverManager.getConnection(url,userName,password);
	 
	}catch(ClassNotFoundException e)
	{
		e.printStackTrace();
	}catch(SQLException e)
	{
		//e.printStackTrace();
		logger.error(e.getMessage());
	}
	return conn;
}
}
