/**
 * 
 */
window.addEventListener('load',function() {
                var form=document.getElementById("signupModal");
            form.addEventListener('submit',function()
                    {
            		alert("the above entered details should be true upto your knowledge and once entered ");
                    var xhr=null;
                        try
                        {
                            xhr=new XMLHttpRequest(); //Chrome, safari, firefox
                        }
                        catch(err)
                        {
                            try
                            {
                                xhr=new ActiveXObject("MSXML2.XMLHttp.6.0");//IE
                            }
                            catch(err)
                            {
                                console.log("ajax object not created");
                            }
                        }
                    
                        xhr.onreadystatechange=function(){
                            var response=null;
                            if(xhr.readyState==4) //successful response
                                {
                                response=xhr.responseText;
                                document.getElementById("result").innerHTML=response;
                                }
                                    
                        }
                        
                        //open the connection
                        xhr.open('post','UserServlet',false); //Userservlet will Initiated dopost
                        xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                        var employeeId=document.getElementById('employeeId').value;
                        var fullName=document.getElementById('fullName').value;
                        var email=document.getElementById('email').value;
                        var address=document.getElementById('address').value;
                        var password=document.getElementById('ldpassword').value;
                        xhr.send("employeeId="+employeeId+"&fullName="+fullName+"&email="+email+"&address="+address+"&password="+password); //send to response
                        return false;
                    });
                  
            
            
            
            
            
            
//            var form=document.getElementById("loginform");
//            form.addEventListener('submit',function()
//                    {
//            			alert("the above entered details should be true upto your knowledge and once entered ");
//                       var xhr=null;
//                        try
//                        {
//                            xhr=new XMLHttpRequest(); //Chrome, safari, firefox
//                        }
//                        catch(err)
//                        {
//                            try
//                            {
//                                xhr=new ActiveXObject("MSXML2.XMLHttp.6.0");
//                            }
//                            catch(err)
//                            {
//                                console.log("ajax object not created");
//                            }
//                        }
//                    
//                        xhr.onreadystatechange=function(){
//                            var response=null;
//                            alert("Entering....");
//                            if(xhr.readyState==4) //successful response
//                                {
//                            	   alert("Entering ready state....");
//                                response=xhr.responseText;
//                                var a=response;
//                                
//                                alert("response: "+response);
//                                if(response==1)
//                                	{                        
//                                		window.location.href="onLoginSuccess.html";
//                                	}
//                                else{  alert("Broooo");       
//                                	window.location.href="index.html";
//                                }
//                                
//                                }
//                                    
//                        }
//                        
//                        //open the connection
//                        alert("open connection");
//                        xhr.open('post','LoginServlet',false);
//                        alert("opened connection");
//                        xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
//                        var userName=document.getElementById('userName').value;
//                        var password=document.getElementById('password').value;
//                        alert("sending......");
//                        xhr.send("userName="+userName+"&password="+password);
//                      
//                    });
            
})