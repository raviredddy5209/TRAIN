function enableField(elements,modify)
	{
		for(var i=0,element;element=elements[i++];){
			if(modify&&element.type==="text"){
				element.removeAttribute("disabled")
			}
			else if(!modify&&element.type==="text"){
				element.setAttribute("disabled","disabled")
			}
			else if(element.type==='button'){
			if(element.style.visibility==='hidden'){
				element.style.visibility='visible';
			}
			else if(element.style.visibility==='visible'){
				element.style.visibility='hidden';
			}
		}
	}
}