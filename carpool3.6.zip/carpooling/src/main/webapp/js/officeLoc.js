function initMap() {
    
    
    var office = {lat: 12.840778, lng: 80.227034};
    var map = new google.maps.Map(
        document.getElementById('map'), {zoom: 17, center: office});
    var marker = new google.maps.Marker({position: office, map: map});

 

}