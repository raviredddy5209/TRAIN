
window.addEventListener('load',function() {
                   var form=document.getElementById("createScheduleForm");
            form.addEventListener('submit',function()
                    {
            		alert("the above entered details should be true upto your knowledge and once entered ");
                    var xhr=null;
                        try
                        {
                            xhr=new XMLHttpRequest(); //Chrome, safari, firefox
                        }
                        catch(err)
                        {
                            try
                            {
                                xhr=new ActiveXObject("MSXML2.XMLHttp.6.0");
                            }
                            catch(err)
                            {
                                console.log("ajax object not created");
                            }
                        }
                    
                        xhr.onreadystatechange=function(){
                            var response=null;
                            if(xhr.readyState==4) //successful response
                                {
                                response=xhr.responseText;
                                alert(response);
                                document.getElementById("result").innerHTML=response;
                                }
                                    
                        }
                        
                        //open the connection
                        xhr.open('post','ScheduleServlet',false);
                        xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                        
                        var employeeId=document.getElementById('employeeId').value;
                        var startingPoint=document.getElementById('startingPoint').value;
                        var endingPoint=document.getElementById('endingPoint').value;
                        var time=document.getElementById('time').value;
                        var vehicleId=document.getElementById('vehicleId').value;
                        var numberOfSeats=document.getElementById('numberOfSeats').value;
                        
                        console.log(numberOfSeats);
                        
                        xhr.send("employeeId="+employeeId+"&startingPoint="+startingPoint+"&endingPoint="+endingPoint+"&time="+time+"&vehicleId="+vehicleId+"&numberOfSeats="+numberOfSeats);
                        
                        return false;
                    });
                  
                    return false;
})