window.onload = FindLocation;


function FindLocation() {


    if (navigator.geolocation) {
        console.log("Geo API supported");
        navigator.geolocation.getCurrentPosition(success, failure);

    }
    else
        console.log("Geo API not supported");


}

function success(position) {
    addressref = document.getElementById("source");

    console.log(position.coords.latitude);
    console.log(position.coords.longitude);
    console.log(position.coords.altitude);
    console.log(position.coords.accuracy);
    console.log(position.coords.altitudeAccuracy);
    console.log(position.coords.speed);
    //  var sectionref = document.getElementById("geoinfo");
    //   sectionref.innerHTML =
    //      "<p> Latitude=<mark>" + position.coords.latitude + "</mark></p><br/>" +
    //     "<p> Longitude=<mark>" + position.coords.longitude + "</mark></p>";

    var latlng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
    geocoder = new google.maps.Geocoder();
    geocoder.geocode({ latLng: latlng }, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            console.log(results);
            if (results[1]) {
                var arrAddress = results;
                console.log(results);
                i = 0;
                addressref.value = "";
                for (var address in arrAddress) {

                    console.log(arrAddress[address]);
                    if (i == 0) {
                        //console.log(arrAddress[address]);
                        // if (arrAddress[address].types[0] == "locality") {
                        addressref.value = arrAddress[address].formatted_address;
                        console.log("City: " + arrAddress[address].formatted_address);
                        itemLocality = arrAddress[address].address_components[0].short_name + ", " + arrAddress[address].address_components[1].short_name;
                        console.log(itemLocality);
                        // }
                        addressref.value = itemLocality;
                        break;

                    }
                    i++;
                }

            } else {
                alert("No results found");
            }
        } else {
            alert("Geocoder failed due to: " + status);
        }
    });
}

function failure(msg) {
    console.log(msg);
}