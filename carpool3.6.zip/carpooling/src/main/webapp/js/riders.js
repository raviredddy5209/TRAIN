


function update(id,obj)
{
	alert("hi inside the update"+id
			+obj.getNumberOfSeats()
	);
	
	
	
	


}
