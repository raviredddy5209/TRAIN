package com.virtusa.carpooling.dao;

public interface RoleDao {

	void createTrip();
	void modifyTrip();
	void cancelTrip();
	
	void enrollRide();
	void cancelRide();
}
