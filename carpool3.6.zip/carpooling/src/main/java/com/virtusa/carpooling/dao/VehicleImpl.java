package com.virtusa.carpooling.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.virtusa.carpooling.helpers.MySQLHelper;

public class VehicleImpl implements VehicleDao {
	private PreparedStatement pre;
	private Connection conn;
	private CallableStatement callable;
	@Override
	public boolean registerVehicle(String vechileNumber, int numberOfSeats,int employeeId) throws SQLException {
		// TODO Auto-generated method stub
		
		conn=MySQLHelper.getConnection();
	
		boolean status = false;

		int count;
		try {
			callable=conn.prepareCall("{call addVehicle(?,?,?)}");
			callable.setString(1, vechileNumber);
			callable.setInt(2, numberOfSeats);
			callable.setInt(3, employeeId);	
			count=callable.executeUpdate();
			if(count>0)
				status=true;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			conn.close();
		}
		
		return status;
	}


}
