package com.virtusa.carpooling.dao;

import java.sql.CallableStatement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.virtusa.carpooling.helpers.MySQLHelper;
import com.virtusa.carpooling.models.mainUser;

public class LoginImpl implements LoginDao {
	private PreparedStatement pre;
	private Connection conn;
	private CallableStatement callable;
	/*
	 * private static Logger logger=Logger.getLogger(LoginImpl.class);
	 * 
	 * 
	 * 
	 * static { PropertyConfigurator.configure("log4j.properties"); }
	 */
	
	@Override
	public boolean Validate(int empid,String pass) throws SQLException {
			conn=MySQLHelper.getConnection();
			ResultSet i=null;
			boolean status = false;
			ResultSet rs;
			int k;
			try {
				callable=conn.prepareCall("{call validateUser(?,?,?)}");
				callable.setInt(1, empid);
				callable.setString(2, pass);
				callable.registerOutParameter(3,java.sql.Types.INTEGER);//new one
				callable.execute();
				k=callable.getInt(3);
				if(k==empid)
					status=true;
				
			} catch (NullPointerException e) {
				// TODO Auto-generated catch block
				status=false;
			}catch(Exception e)
				{
					e.printStackTrace();
				}
			
			finally {
				conn.close();
			}
			
			return status;
		}

	}
