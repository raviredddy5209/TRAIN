package com.virtusa.carpooling.dao;

import java.sql.SQLException;

import com.virtusa.carpooling.models.mainUser;

public interface LoginDao {
	
	boolean Validate(int id,String password) throws SQLException;

}
