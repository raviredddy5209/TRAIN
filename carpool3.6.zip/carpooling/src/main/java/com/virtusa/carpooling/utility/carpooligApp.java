package com.virtusa.carpooling.utility;

public class carpooligApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
