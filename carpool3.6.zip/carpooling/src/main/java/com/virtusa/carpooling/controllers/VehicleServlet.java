package com.virtusa.carpooling.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.carpooling.dao.LoginDao;
import com.virtusa.carpooling.dao.LoginImpl;
import com.virtusa.carpooling.dao.ScheduleDao;
import com.virtusa.carpooling.dao.ScheduleImpl;
import com.virtusa.carpooling.dao.VehicleDao;
import com.virtusa.carpooling.dao.VehicleImpl;
import com.virtusa.carpooling.models.Schedule;

/**
 * Servlet implementation class VehicleServlet
 */
public class VehicleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VehicleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		 HttpSession session=request.getSession();
		
		 VehicleDao dao=new VehicleImpl();
		
 	   String employeeId= request.getParameter("employeeId");
 	   String vehicleId= request.getParameter("vehicleId");
 	   String numberOfSeats= request.getParameter("numberOfSeats");
       boolean status=false;
       try {
      
        	try {
				status=dao.registerVehicle(vehicleId, Integer.parseInt(numberOfSeats),Integer.parseInt(employeeId));
			} catch (NumberFormatException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
          	
       	}
         catch (NullPointerException e) {
  			request.setAttribute("error", "credintial can't be empty");
  			request.getRequestDispatcher("ErrorServlet").include(request, response);
  			request.getRequestDispatcher("index.jsp").include(request, response);
  		}
       if(status)  {
    	   session.setAttribute("vehicleId",vehicleId);
    	   session.setAttribute("numberOfSeats",numberOfSeats);
    	   
    	   		out.print("record Added");
       }
       else
       {
    	   out.print("Failed to add");
    	   
       }
 }

}
