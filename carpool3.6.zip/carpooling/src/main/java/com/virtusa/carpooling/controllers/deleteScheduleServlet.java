package com.virtusa.carpooling.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.carpooling.dao.ScheduleDao;
import com.virtusa.carpooling.dao.ScheduleImpl;

/**
 * Servlet implementation class deleteScheduleServlet
 */
public class deleteScheduleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deleteScheduleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
//		doGet(request, response);
		boolean status = false;
		
		ScheduleDao dao=new ScheduleImpl();
		try {
			status=dao.deleteSchedule();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 if(status)
			System.out.println("Record deleted sucessfully");
		 else
			 System.out.println("Deletion Failed");
		
		
	}

}
