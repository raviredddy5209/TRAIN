package com.virtusa.carpooling.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.carpooling.helpers.MySQLHelper;
import com.virtusa.carpooling.models.Schedule;

public class ScheduleImpl implements ScheduleDao{

	private PreparedStatement pre;
	private Connection conn;
	private CallableStatement callable;
	
	private static Logger logger=Logger.getLogger(UserAccImpl.class);
	
	
	
	static {
		PropertyConfigurator.configure("log4j.properties");
	}



	@Override
	public boolean addSchedule(Schedule schedule) throws SQLException{
		// TODO Auto-generated method stub
		conn=MySQLHelper.getConnection();
		int count=0;
		boolean status=false;
		try {
			callable=conn.prepareCall("{call addSchedule(?,?,?,?,?,?)}");
			callable.setInt(1, schedule.getEmployeeId());
			callable.setString(2, schedule.getStartingPoint());
			callable.setString(3, schedule.getEndingPoint());
			callable.setTime(4, schedule.getTime());
			callable.setString(5, schedule.getVehicleId());
			callable.setInt(6, schedule.getNumberOfSeats());
			
			count=callable.executeUpdate();
			if(count>0)
				status=true;
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			conn.close();
		}
		
		return status;
	}
	@Override
    public List<Schedule> getUserById(String startingPoint, String endingPoint) throws SQLException {
        // TODO Auto-generated method stub
         conn=MySQLHelper.getConnection();
         List<Schedule> schedules=new ArrayList<Schedule>();
         Schedule schedule=null;
            ResourceBundle bundle=ResourceBundle.getBundle("com/virtusa/carpooling/resources/db");
            String query=bundle.getString("searchQuery");
            try {
            pre=conn.prepareStatement(query);
            pre.setString(1,startingPoint);
            pre.setString(2,endingPoint);
            
            ResultSet rs=pre.executeQuery();
           // rs.next();
            //stored retrived in sc
            
            while(rs.next()) {
            Schedule sc=new Schedule();
            sc.setScheduleId(rs.getInt(1));
            sc.setEmployeeId(rs.getInt(2));
            sc.setStartingPoint(rs.getString(3));
            sc.setEndingPoint(rs.getString(4));
            sc.setTime(rs.getString(5));
            sc.setVehicleId(rs.getString(6));
            sc.setNumberOfSeats(rs.getInt(7));
            schedules.add(sc);
            }}catch (SQLException e) {
                // TODO: handle exception
                e.printStackTrace();
            
            }
            finally {
            conn.close();
            }

 


            return schedules;
     
    }



	@Override
	public boolean updateSchedule(Schedule scheduleId) {
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public boolean deleteSchedule() throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQLHelper.getConnection();
		boolean status=false;
		
		ResourceBundle bundle=ResourceBundle.getBundle("com/virtusa/carpooling/resources/db");
        String query=bundle.getString("deleteQuery");
        status=callable.execute(query);
        
        
        
 
		return status;
	}
	@Override
	public boolean decrementById(String VehicleId) throws SQLException {
		// TODO Auto-generated method stub
		 
	    conn=MySQLHelper.getConnection();
	     	int count = 0;
			 boolean status=false;
				ResourceBundle bundle=ResourceBundle.getBundle("com/virtusa/carpooling/resources/db");
		        String query=bundle.getString("updatecountquery");
		        
		        try {
		            pre=conn.prepareStatement(query);
		           
		                 pre.setString(1, VehicleId);
		                count=pre.executeUpdate();
		                if(count>0)
		                status=true;
		         
		        }catch (SQLException e) {
					// TODO: handle exception
				}
		        
		        
		        
		        
		        
		        
		        
		return status;
	}
	
}
