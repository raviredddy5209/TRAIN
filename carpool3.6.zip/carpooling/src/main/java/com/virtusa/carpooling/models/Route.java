package com.virtusa.carpooling.models;

public class Route {

	 

    private String origin;
    private String destination;
    
    public String getOrigin() {
        return this.origin;
    }
    public void setOrigin(String origin) {
        this.origin = origin;
    }
    public String getDestination() {
        return this.destination;
    }
    public void setDestination(String destination) {
        this.destination = destination;
    }
    
}
 