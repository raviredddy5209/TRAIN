package com.virtusa.carpooling.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.carpooling.dao.UserAccImpl;
import com.virtusa.carpooling.dao.UserAccountDao;
import com.virtusa.carpooling.models.mainUser;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		Enumeration<String> enumeration=request.getParameterNames(); //receives from index.js
		response.setContentType("text/html");//Output type
        String name=null;
        mainUser user=new mainUser();//Initializing fojo class
        Hashtable<String, String> ht=new Hashtable<String,String>();
        
        boolean match=false;
        
        while(enumeration.hasMoreElements())
        {
            name=enumeration.nextElement();
            //out.println(name+":"+request.getParameter(name)+"<br/>");
            ht.put(name,request.getParameter(name));
        }
        user.setEmpId(Long.parseLong(ht.get("employeeId")));
        user.setFullName(ht.get("fullName"));
        user.setEmail(ht.get("email"));
        user.setAddress(ht.get("address"));
        user.setPassword(ht.get("password"));
        user.setRoleId(0);
	        UserAccountDao uai=new UserAccImpl();
	        boolean status=false;
	        try {
	            status=uai.addUser(user); //status returned from UserAccountImpl class
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        if(status)
	            out.println("Record added successfully");//writes on response
	        else
	           out.println("Record not added");

	}

}
