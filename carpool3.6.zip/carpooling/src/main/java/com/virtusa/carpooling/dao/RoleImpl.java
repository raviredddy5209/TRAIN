package com.virtusa.carpooling.dao;

public class RoleImpl {

}
