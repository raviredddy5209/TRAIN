package com.virtusa.carpooling.dao;

import java.sql.SQLException;


import com.virtusa.carpooling.models.UserAccount;
import com.virtusa.carpooling.models.mainUser;

public interface UserAccountDao {
	
boolean addUser(mainUser user) throws SQLException;


mainUser getUserById(int empid) throws SQLException;

}
