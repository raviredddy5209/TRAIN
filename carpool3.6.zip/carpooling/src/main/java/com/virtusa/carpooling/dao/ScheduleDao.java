package com.virtusa.carpooling.dao;
import java.sql.SQLException;
import java.util.List;

import com.virtusa.carpooling.models.*;
public interface ScheduleDao {

	boolean addSchedule(Schedule scheduleId) throws SQLException;
	boolean updateSchedule(Schedule scheduleId) throws SQLException;
	boolean deleteSchedule() throws SQLException;
	boolean decrementById(String VehicleId) throws SQLException;
	List <Schedule> getUserById(String startingPoint,String endingPoint)  throws SQLException;
}
