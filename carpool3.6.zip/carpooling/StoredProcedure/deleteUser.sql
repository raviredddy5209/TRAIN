DELIMITER $$

DROP PROCEDURE IF EXISTS deleteUser $$

CREATE PROCEDURE deleteUser(in p_employeeId INTEGER(20))
BEGIN

delete from user where employeeId =p_employeeId;
END $$

DELIMITER ;