DELIMITER $$

DROP PROCEDURE IF EXISTS validateUser $$
create procedure validateUser(in p_employeeId int(20),in p_password varchar(30),out result int(20))

BEGIN

select employeeId into result from user where employeeId=p_employeeId and password=p_password;

END $$
DELIMITER ;
