DELIMITER $$
 DROP PROCEDURE IF EXISTS addSchedule $$
create procedure addSchedule(in p_employeeId integer(20),
in p_startingPoint varchar(30),
in p_endingPoint varchar(50),
in p_startTime time,
in p_vehicleId varchar(30),
in p_numberOfSeats integer(20))
BEGIN
insert into schedule(employeeId,startingPoint,endingPoint,startTime,vehicleId,numberOfSeats) values(p_employeeId, p_startingPoint, p_endingPoint, p_startTime,p_vehicleId,p_numberOfSeats);
END $$
DELIMITER ;
 