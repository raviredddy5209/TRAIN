DELIMITER $$

DROP PROCEDURE IF EXISTS modifyUserProfile $$
create procedure modifyUserProfile(in p_employeeId integer(20),
in p_fullName varchar(30),
in p_email varchar(50),
in p_address varchar(50),
in p_password varchar(30))
BEGIN

update user set fullName=p_fullName, email=p_email, address=p_address, password=p_password
where employeeId=p_employeeId;
END $$
DELIMITER ;
