DELIMITER $$

DROP PROCEDURE IF EXISTS modifyCount $$
create procedure modifyCount(in p_VehicleId varchar(30))
BEGIN
update vehicle  
SET availableSeats=availableSeats - 1;
END $$
DELIMITER ;
