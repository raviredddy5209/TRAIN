DELIMITER $$

DROP PROCEDURE IF EXISTS addUser $$
create procedure addUser(in p_employeeId bigint(20)
,in p_fullName varchar(30),
in p_email varchar(50),
in p_address varchar(50),
in p_password varchar(30),
in p_role_Id int(1))

BEGIN

insert into user values(p_employeeId,p_fullName,p_email,p_address,p_password,0);

END $$
DELIMITER ;
