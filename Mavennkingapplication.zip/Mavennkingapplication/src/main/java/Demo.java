import java.util.Scanner;
public class Demo {

	public static void main(String[] args) {
		String ticktype;
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the type");
		   ticktype=sc.nextLine();
	       //sc.nextLine();
	       ticktype.toLowerCase();
	       switch(ticktype) {
	       
	       case   "business" :
	    	   System.out.println("cost is" + 9999) ;
	    	   break;
	       case   "economy" :
	    	   System.out.println("cost is" + 3999) ;
	    	   break;
	       }
 
	}

}
 