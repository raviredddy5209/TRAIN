package com.virtusa.banking.utility.Mavennkingapplication;
import java.util.Scanner;
public class Billing {

	public static void main(String[] args) {
		// TODO Auto-new  method stub
		int i;
		Scanner sc = new Scanner(System.in);
		Product[] products = new Product[3];
		for(i=0;i<3;i++) 
		{
			products[i] = new Product();
		}
		products[i].setproductNo(sc.nextInt())
		
	}

}
