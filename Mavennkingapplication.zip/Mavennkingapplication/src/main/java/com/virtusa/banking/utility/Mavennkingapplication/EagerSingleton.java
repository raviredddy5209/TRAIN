package com.virtusa.banking.utility.Mavennkingapplication;

public class EagerSingleton {
	private EagerSingleton() {}
		private static final EagerSingleton instanc = new EagerSingleton();
		public static EA
}
