package com.virtusa.banking.utility.Mavennkingapplication;

public class EagerStaticBlockSingleton {
private static final  EagerStaticBlockSingleton instance;                       

	private  EagerStaticBlockSingleton () {}
		static {
			 try {
				 instance = new  EagerStaticBlockSingleton ();
				 
			 }catch(Exception e) {
			 	 throw e;
			 }
		}
		public static  EagerStaticBlockSingleton  getInstance() {
			return instance;
		}
}
