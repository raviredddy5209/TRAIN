package com.virtusa.banking.utility.Mavennkingapplication;

public class Product {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
