package com.virtusa.banking.utility.Mavennkingapplication;
import java.util.Calendar;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

/**
 * @author ravireddy
 * @version 1.0 Banking Application
 *
 */
public class App 
{
	/**
	 * 
	 * @param args command line parameters
	 */
	
    public static void main( String[] args )
    {
    	String doj;
    	Date joiningDate=null;
    	Date experience;
         
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter name");
        String firstname=sc.nextLine();
        System.out.println("Enter age");
        byte age=sc.nextByte();
        sc.nextLine();
        
        System.out.println("Enter DOJ (dd-mm-yyyy)\n");
        doj = sc.nextLine();
        int jy = Integer.parseInt(doj.split("-")[2]);
        int cy = Calendar.getInstance().get(Calendar.YEAR);
        
        //Date conversion
       /** SimpleDateFormat  formatter = new SimpleDateFormat("dd-MM-yyyy");
        try
        {
        	joiningDate= formatter.parse(doj);
        }catch(ParseException e)
        {
        	e.printStackTrace();
        }
        
        System.out.println("Name=\t" + firstname+"\n"+ "Age=\t" + age);
        System.out.println("DOJ" + joiningDate.toString());
        //System.out.println(new Date().getYear()-joiningDate.getYear());
        */
        System.out.println("Experience is" + (cy-jy));
        
    }
}
