package com.virtusa.banking.utility.Mavennkingapplication;

import java.util.Scanner;

public class limiters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String temp;
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the string");
		String word=scanner.nextLine();
		String splitarr[]=word.split(" ");
	}

}
