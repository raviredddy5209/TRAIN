package com.virtusa.shopping.dao;

 

import java.util.List;
import com.virtusa.shopping.models.Category;

 

public interface CategoryDao {
    List<Category> getAllCategories();
}