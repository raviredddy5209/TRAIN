package com.virtusa.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.virtusa.shopping.helpers.MySQLHelper;
import com.virtusa.shopping.models.Booking;

public class BookingImpl implements BookingDao{
	private Connection conn;
	private PreparedStatement pre;
	@Override
	public int addBooking(Booking booking) throws SQLException {
		// TODO Auto-generated method stub
		conn=MySQLHelper.getConnection();
		ResourceBundle rb = ResourceBundle.getBundle("com/virtusa/shopping/resources/db");
		String query = rb.getString("addbooking");
		int count=0;
		System.out.println(booking.getMobileNo());
//		try
//		{
//			pre=conn.prepareStatement(query);
//		pre.setLong(1, booking.getMobileNo());
//		pre.setString(2, booking.getSeats());
//		pre.setBoolean(3, true);
//		count = pre.executeUpdate();
//		}catch (SQLException e) {
//			// TODO: handle exception
//		}
//		finally {
//			conn.close();
//		}
		return count;
	}

}
