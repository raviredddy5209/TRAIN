
	
	package com.virtusa.shopping.dao;

	 

	import java.util.ArrayList;
	import java.util.List;
	import java.util.ResourceBundle;
	import java.sql.Connection;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;

	 


	import com.virtusa.shopping.helpers.MySQLHelper;
	import com.virtusa.shopping.models.Category;

	 

	public class CategoryImpl implements CategoryDao {

	 

	    private Connection conn;
	    private Statement statement;
	    private ResultSet resultSet;
	    
	    @Override
	    public List<Category> getAllCategories() {
	        // TODO Auto-generated method stub
	        conn=MySQLHelper.getConnection();
	        List<Category> categories=new ArrayList<Category>();
	        Category category=null;
	        ResourceBundle rBundle=ResourceBundle.getBundle("com/virtusa/shopping/resources/db");
	        String query=rBundle.getString("getAllCategories");
	        
	        try {
	            statement=conn.createStatement();
	            resultSet = statement.executeQuery(query);
	            while(resultSet.next()) {
	                category=new Category();
	                category.setCategoryId(resultSet.getInt(1));
	                category.setCategoryName(resultSet.getString(2));
	                categories.add(category);
	            }
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        
	        
	        
	        return categories;
	    }

	 

	}
	 

