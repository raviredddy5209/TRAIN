package com.virtusa.shopping.dao;

import java.sql.SQLException;

import com.virtusa.shopping.models.Booking;

public interface BookingDao {
 int addBooking(Booking booking) throws SQLException;
}
