package com.virtusa.shopping.models;

public class Booking {
  private long MobileNo;
  private String seats;
public long getMobileNo() {
	return MobileNo;
}
public void setMobileNo(long mobileNo) {
	MobileNo = mobileNo;
}
public String getSeats() {
	return seats;
}
public void setSeats(String seats) {
	this.seats = seats;
}
}
