 window.addEventListener('load',function()
{
    document.getElementById("proceed").addEventListener('click',function()
    {
        window.open("payment.jsp");
    })
    
    
    })

 

function disable(id)
{   
    if(window.sessionStorage.getItem("seats")!=null)
        {
        window.sessionStorage.setItem("seats",id+","+window.sessionStorage.getItem("seats"));
        }
    else
    window.sessionStorage.setItem("seats",id);
    
    var img=new Image();
    img.src="images/cw.jpg";
    img.width="50";
    img.height="50";
    var aref=document.getElementById(id);
    while(aref.hasChildNodes())
        aref.removeChild(aref.firstChild);
    
    aref.appendChild(img);
}