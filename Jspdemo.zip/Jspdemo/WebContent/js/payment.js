
    window.addEventListener('load',function(){
    if(window.sessionStorage.getItem("seats")!=null){
       
        var seats=document.getElementById("seats");
        seats.value=window.sessionStorage.getItem("seats");
       
    }
})
