package com.virtusa.asng;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
public class Assg{
 private static String dob;
 static Date date;
 static SimpleDateFormat ft=new SimpleDateFormat("dd-MM-yyyy");
 public static void main(String[] args) {
 Scanner scanner=new Scanner(System.in);
 dob=scanner.nextLine();
 try {
  date =ft.parse(dob);
 } catch (ParseException e) {
  // TODO Auto-generated catch block
  e.printStackTrace();
 }
    Calendar cal=Calendar.getInstance();
  cal.setTime(date);
//    cal.set(date.getYear(), date.getMonth(), date.getDate());
    System.out.println("your date of birth is: "+cal.getTime());
    
}
}
